# J.A.R.V.I.S. MAXIMUM 2.0 (Android)

Kotlin + Jetpack Compose. Destino: Motorola G24, Android 14 (minSdk 26, targetSdk 35).
**Sin dependencias nuevas** respecto a la versión anterior (solo Compose, Activity, Core).

> **Estado honesto:** este código se escribió y revisó a mano, pero **no se ha compilado ni probado en un teléfono**
> por quien lo escribió. La primera compilación en GitHub puede mostrar algún error; si ocurre, envíe la captura del error.

## Cómo compilar (GitHub Actions, como ya lo hace)
1. Reemplace `JARVIS_ANDROID_SOURCE.zip` en su repositorio por el nuevo (mismo nombre).
2. Actions → *Build JARVIS Android APK* → *Run workflow*.
3. Descargue el artefacto `JARVIS-MAXIMUM-APK`, extraiga `app-debug.apk`.
4. **Desinstale la versión anterior antes de instalar** (cada compilación en GitHub se firma con una clave de depuración distinta; Android rechaza actualizar encima).

Compilación local: JDK 17, Android SDK 35, `gradle wrapper --gradle-version 8.9` y `./gradlew assembleDebug`.

## Configurar la IA (Ajustes ▸ Inteligencia artificial)
La app no trae ninguna clave ni proveedor. Usted elige uno y pone su propia clave (queda cifrada con Android Keystore).
- **Compatible con OpenAI**: dirección (vacío = `https://api.openai.com/v1`), modelo y clave. Sirve también para otros servicios con el mismo formato (`POST {base}/chat/completions`).
- **Anthropic**: modelo y clave (`POST {base}/messages`).
- Solo HTTPS. Pulse **Probar conexión**. Los proveedores pueden cobrar; revise sus condiciones.
- Sin proveedor o sin Internet, la app lo indica y pasa al modo local.

## Funciones implementadas (en código)
- IA modular (2 proveedores), contexto de conversación, memoria local, nueva conversación automática tras 30 min o por orden («nueva conversación»), resumen de archivos de texto (.txt/.md/.csv/.json…).
- Reconocimiento de voz dentro de la app (`SpeechRecognizer`), con animación, texto parcial, cancelar, «Repetir» y gestión de permisos. No abre Google.
- Voz: selector de motor y de voz (español), velocidad, tono, prueba, ajustes persistentes. Quita markdown/código antes de hablar.
- Palabra de activación (configurable, por defecto «jarvis»): servicio en primer plano con notificación, botón de apagado, estado visible.
- Interfaz holográfica: anillos animados, ondas reactivas al micrófono, panel de conversación, reloj, chips de conexión/IA/micrófono/batería, panel de ajustes.
- Teléfono: abrir apps, hora, fecha, batería, conexión, ajustes (generales y por sección), volumen multimedia, alarmas, temporizadores y recordatorios (vía app Reloj), información del dispositivo.
- Contactos (con permiso), llamadas (abre el marcador), SMS y WhatsApp **preparados**; siempre con confirmación.
- Memoria: ver, borrar, desactivar; datos («recuerda que…»), nombre del usuario y del asistente.
- Modo sin conexión: comandos locales, memoria, respuestas básicas, calculadora sencilla.

## Limitaciones reales (no se disimulan)
- Nada se envía ni se llama solo: se abre el marcador/WhatsApp/SMS con el contenido listo y **usted pulsa enviar/llamar**.
- La alarma/temporizador se deja preparado en la app Reloj; la app no puede verificar que quedó activo.
- Con la app en segundo plano Android prohíbe abrir otras apps: se deja una notificación para tocar.
- Palabra de activación: gasta batería, puede detenerla el sistema, el reconocedor puede pitar, solo se inicia con la app abierta y no arranca sola al reiniciar.
- La voz depende de los motores TTS instalados; Android no indica si una voz es masculina. No incluye ni imita la voz de la película.
- Reconocimiento: lo hace el servicio del teléfono (normalmente Google); sin Internet requiere el idioma descargado.
- No puede borrar alarmas ni cambiar el modo silencio/No molestar.
- PDF y Word no se resumen (solo texto plano).

## Estructura
`data/` ajustes, cifrado de clave, memoria · `ai/` proveedores · `voice/` TTS y STT · `phone/` funciones del teléfono ·
`core/` controlador, comandos, modo offline · `service/` palabra de activación · `ui/` pantallas.
