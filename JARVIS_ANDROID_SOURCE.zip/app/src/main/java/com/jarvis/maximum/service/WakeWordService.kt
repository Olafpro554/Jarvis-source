package com.jarvis.maximum.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.maximum.JarvisApp
import com.jarvis.maximum.MainActivity

/**
 * Servicio en primer plano (tipo micrófono) con notificación persistente.
 * Mantiene vivo el proceso mientras el controlador escucha la palabra de activación.
 * Solo se puede iniciar con la app a la vista (Android 14) y no se reinicia solo tras un reinicio del teléfono.
 */
class WakeWordService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val controller = JarvisApp.instance.controller
        if (intent?.action == ACTION_STOP) {
            controller.disableWake()
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            controller.onWakeFailed("Android no permitió iniciar la escucha en segundo plano: ${e.message ?: "error desconocido"}")
            stopSelf()
            return START_NOT_STICKY
        }
        controller.onWakeServiceStarted()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        JarvisApp.instance.controller.onWakeServiceStopped()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Escucha de «J.A.R.V.I.S.»", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val word = JarvisApp.instance.controller.settings.wakeWord
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("J.A.R.V.I.S. está escuchando")
            .setContentText("Diga «$word» para activarlo. Usa el micrófono y algo de batería.")
            .setContentIntent(open)
            .addAction(0, "Desactivar", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    companion object {
        const val CHANNEL = "jarvis_wake"
        const val NOTIF_ID = 4200
        const val ACTION_STOP = "com.jarvis.maximum.STOP_WAKE"
    }
}
