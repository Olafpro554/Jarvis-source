package com.jarvis.maximum

import android.app.Application
import com.jarvis.maximum.core.JarvisController

/** Contenedor único del asistente: vive mientras viva el proceso (actividad y servicio lo comparten). */
class JarvisApp : Application() {
    lateinit var controller: JarvisController
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        controller = JarvisController(this)
    }

    companion object {
        lateinit var instance: JarvisApp
            private set
    }
}
