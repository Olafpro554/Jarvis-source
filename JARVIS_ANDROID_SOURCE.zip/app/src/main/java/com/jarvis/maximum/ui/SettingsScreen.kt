package com.jarvis.maximum.ui

import android.Manifest
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.maximum.core.JarvisController
import com.jarvis.maximum.core.Screen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(c: JarvisController) {
    val s = c.settings
    var confirm by remember { mutableStateOf<String?>(null) }
    var keyInput by remember { mutableStateOf("") }
    var keyMsg by remember { mutableStateOf<String?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    val bg = Brush.verticalGradient(listOf(Holo.Bg0, Holo.Bg1, Holo.Bg2))

    Column(Modifier.fillMaxSize().background(bg).systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { c.screen = Screen.MAIN }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver", tint = Holo.Cyan)
            }
            Text("AJUSTES", color = Holo.Cyan2, fontSize = 18.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Light)
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------------------------------------------------------------- Estado
            Section("ESTADO") {
                Body(c.aiStatusText())
                Body(if (c.online) "Conexión: hay Internet." else "Conexión: sin Internet (modo local).")
            }

            // ---------------------------------------------------------------- Identidad
            Section("IDENTIDAD") {
                Field("Nombre del asistente", s.assistantName) { s.assistantName = it }
                Field("Su nombre (opcional)", s.userName) { s.userName = it }
            }

            // ---------------------------------------------------------------- IA
            Section("INTELIGENCIA ARTIFICIAL") {
                Body("Elija un proveedor y escriba su propia clave API. La clave se guarda cifrada en este teléfono (Android Keystore); no viene incluida en la aplicación. Los proveedores pueden cobrar por el uso: revise sus condiciones.")
                Chips(
                    listOf("none" to "Ninguno", "openai" to "Compatible OpenAI", "anthropic" to "Anthropic"),
                    s.aiProvider
                ) { s.aiProvider = it; c.aiTestResult = null }
                if (s.aiProvider != "none") {
                    Field("Dirección del servicio (vacío = oficial)", s.aiBaseUrl, hint = c.ai.defaultBase(s.aiProvider)) { s.aiBaseUrl = it }
                    Field(
                        "Modelo",
                        s.aiModel,
                        hint = if (s.aiProvider == "anthropic") "p. ej. claude-haiku-5-5" else "p. ej. gpt-4o-mini"
                    ) { s.aiModel = it }
                    Body("Los nombres de modelo cambian con el tiempo: use uno vigente en la documentación de su proveedor.")
                    Field("Clave API", keyInput, password = true, hint = if (c.secure.hasKey) "Clave guardada (escriba otra para reemplazarla)" else "Pegue su clave") {
                        keyInput = it
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            keyMsg = if (c.secure.saveApiKey(keyInput)) "Clave guardada cifrada." else "No se pudo guardar la clave."
                            keyInput = ""
                        }) { Text("Guardar clave") }
                        OutlinedButton(onClick = { c.secure.clear(); keyMsg = "Clave borrada." }) { Text("Borrar clave") }
                    }
                    keyMsg?.let { Body(it) }
                    Button(onClick = { c.testAi() }) { Text("Probar conexión") }
                    c.aiTestResult?.let { Body(it) }
                    Body("Solo se acepta HTTPS. Para uso offline no se necesita proveedor: solo funcionan los comandos locales.")
                }
            }

            // ---------------------------------------------------------------- Voz
            Section("VOZ DE SALIDA") {
                Body(c.tts.status)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body("Hablar las respuestas", Modifier.weight(1f))
                    Switch(checked = s.speakReplies, onCheckedChange = { s.speakReplies = it })
                }
                Label("Motor de voz")
                Chips(
                    listOf("" to "Predeterminado") + c.tts.engines.map { it.packageName to it.label },
                    s.ttsEngine
                ) { c.tts.selectEngine(it) }
                Label("Voz (español)")
                if (c.tts.voices.isEmpty()) {
                    Body("El motor actual no lista voces en español. Pruebe otro motor o instale voces en los ajustes de texto a voz del teléfono.")
                } else {
                    c.tts.voices.take(40).forEach { v ->
                        val sel = s.ttsVoice == v.name
                        Text(
                            (if (sel) "● " else "○ ") + v.label,
                            color = if (sel) Holo.Cyan else Holo.Text,
                            fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth().clickable { c.tts.selectVoice(v.name) }.padding(vertical = 6.dp)
                        )
                    }
                    Body("Android no indica de forma fiable si una voz es masculina o femenina: pruebe cada una. Para un tono más grave, baje el «tono».")
                }
                Label("Velocidad: " + String.format(Locale.US, "%.2f", s.ttsRate))
                Slider(value = s.ttsRate, onValueChange = { s.ttsRate = it }, valueRange = 0.5f..1.5f)
                Label("Tono: " + String.format(Locale.US, "%.2f", s.ttsPitch))
                Slider(value = s.ttsPitch, onValueChange = { s.ttsPitch = it }, valueRange = 0.5f..1.3f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { c.tts.testVoice(s.assistantName) }) { Text("Probar voz") }
                    OutlinedButton(onClick = {
                        c.launch(listOf(Intent("com.android.settings.TTS_SETTINGS")), "", "abrir los ajustes de texto a voz")
                    }) { Text("Ajustes del motor") }
                }
                Body("Las voces vienen de los motores instalados en el teléfono (p. ej. Google). Esta app no incluye ni imita la voz de ninguna película.")
            }

            // ---------------------------------------------------------------- Reconocimiento
            Section("RECONOCIMIENTO DE VOZ") {
                Body("Escucha dentro de la app, sin abrir Google. Idioma:")
                Chips(
                    listOf("es-PE" to "Perú", "es-MX" to "México", "es-US" to "EE. UU.", "es-ES" to "España"),
                    s.recognitionLanguage
                ) { s.recognitionLanguage = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body("Preferir reconocimiento sin Internet (si el idioma está descargado)", Modifier.weight(1f))
                    Switch(checked = s.preferOfflineRecognition, onCheckedChange = { s.preferOfflineRecognition = it })
                }
                Body(if (c.speech.isAvailable()) "Servicio de reconocimiento del teléfono: disponible." else "Servicio de reconocimiento del teléfono: NO disponible.")
            }

            // ---------------------------------------------------------------- Palabra de activación
            Section("PALABRA DE ACTIVACIÓN") {
                Field("Palabra", s.wakeWord) { s.wakeWord = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body("Escuchar la palabra de activación", Modifier.weight(1f))
                    Switch(checked = s.wakeWordEnabled, onCheckedChange = { c.setWakeEnabled(it) })
                }
                Body("Estado: ${c.wakeStatus}")
                Body("Funciona con un servicio en primer plano y una notificación permanente. Usa el micrófono de forma continua y gasta batería; el reconocimiento puede emitir un pitido en algunos teléfonos, y Android o el ahorro de batería pueden detenerlo. Solo se activa con la app abierta y no se reinicia solo al encender el teléfono. Con la pantalla bloqueada no puedo abrir aplicaciones: dejaré una notificación para tocar.")
            }

            // ---------------------------------------------------------------- Memoria
            Section("MEMORIA LOCAL") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body("Guardar y usar memoria", Modifier.weight(1f))
                    Switch(checked = s.memoryEnabled, onCheckedChange = { c.setMemoryEnabled(it) })
                }
                Body("Se guarda solo en este teléfono. Al desactivarla dejo de guardar y de usar datos anteriores (lo ya guardado permanece hasta que lo borre). Para que la IA continúe una conversación, se envía a su proveedor el contexto reciente.")
                Body("Mensajes guardados: ${c.memory.messages.size}. Datos recordados: ${c.memory.facts.size}.")
                c.memory.facts.forEachIndexed { i, f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Body("• $f", Modifier.weight(1f))
                        IconButton(onClick = { c.memory.removeFact(i) }) {
                            Icon(Icons.Default.Close, contentDescription = "Olvidar", tint = Holo.Warn)
                        }
                    }
                }
                TextButton(onClick = { showHistory = !showHistory }) {
                    Text(if (showHistory) "Ocultar historial" else "Ver historial", color = Holo.Cyan)
                }
                if (showHistory) {
                    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale("es", "PE")) }
                    c.memory.messages.takeLast(40).forEach { m ->
                        val who = when (m.role) {
                            "user" -> "Usted"
                            "assistant" -> s.assistantName
                            else -> "Aviso"
                        }
                        Text("${fmt.format(Date(m.time))} · $who: ${m.text.take(160)}", color = Holo.Dim, fontSize = 11.sp)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { confirm = "history" }) { Text("Borrar historial") }
                    OutlinedButton(onClick = { confirm = "all" }) { Text("Borrar todo") }
                }
            }

            // ---------------------------------------------------------------- Teléfono
            Section("TELÉFONO Y PERMISOS") {
                Field("Prefijo telefónico del país (para WhatsApp), p. ej. 51", s.countryCode) { s.countryCode = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        c.requestPermission?.invoke(Manifest.permission.READ_CONTACTS, {}, {})
                    }) { Text("Contactos") }
                    OutlinedButton(onClick = {
                        c.requestPermission?.invoke(Manifest.permission.POST_NOTIFICATIONS, {}, {})
                    }) { Text("Notificaciones") }
                    OutlinedButton(onClick = {
                        c.requestPermission?.invoke(Manifest.permission.RECORD_AUDIO, {}, {})
                    }) { Text("Micrófono") }
                }
                Body("Las llamadas y los mensajes se preparan y usted los confirma y envía; J.A.R.V.I.S. nunca afirma haberlos realizado.")
            }

            Section("ACERCA DE") {
                Body("J.A.R.V.I.S. MAXIMUM 2.0. Compilado sin probar en dispositivo por el autor de este código: si algo falla, descríbame el error.")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == "all") "¿Borrar toda la memoria?" else "¿Borrar el historial?") },
            text = {
                Text(
                    if (kind == "all") "Se borrarán el historial, los datos recordados y su nombre."
                    else "Se borrarán todas las conversaciones guardadas."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == "all") c.memory.clearAll() else c.memory.clearHistory()
                    confirm = null
                }) { Text("Borrar") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Holo.Cyan.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .background(Color(0x55061B2B), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = Holo.Cyan, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Medium)
        content()
    }
}

@Composable
private fun Body(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Holo.Text, fontSize = 12.sp, lineHeight = 17.sp, modifier = modifier)
}

@Composable
private fun Label(text: String) {
    Text(text, color = Holo.Dim, fontSize = 11.sp, letterSpacing = 1.sp)
}

@Composable
private fun Field(
    label: String,
    value: String,
    password: Boolean = false,
    hint: String = "",
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, fontSize = 12.sp) },
        placeholder = { if (hint.isNotEmpty()) Text(hint, color = Holo.Dim, fontSize = 12.sp) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Holo.Cyan,
            unfocusedBorderColor = Color(0x6646BBD8),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLabelColor = Holo.Cyan,
            unfocusedLabelColor = Holo.Dim,
            cursorColor = Holo.Cyan
        )
    )
}

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (id, label) ->
            val sel = id == selected
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, if (sel) Holo.Cyan else Holo.Dim.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .background(if (sel) Holo.Cyan.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { onSelect(id) }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(label, color = if (sel) Holo.Cyan else Holo.Text, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}
