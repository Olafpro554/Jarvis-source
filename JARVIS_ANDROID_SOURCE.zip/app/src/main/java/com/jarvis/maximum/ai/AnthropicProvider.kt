package com.jarvis.maximum.ai

import org.json.JSONArray
import org.json.JSONObject

/** API de mensajes de Anthropic: POST {base}/messages. Modelo y clave los pone el usuario. */
class AnthropicProvider(
    private val baseUrl: String,
    private val model: String,
    private val apiKey: String
) : AiProvider {

    override fun chat(system: String, history: List<AiMessage>): AiResult {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1500)
            .put("system", system)
            .put("messages", msgs)
            .toString()
        val headers = mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01")

        val (code, text) = Http.postJson(baseUrl.trimEnd('/') + "/messages", headers, body)
        if (code !in 200..299) return AiResult.Err(Http.errorText(code, text))
        return try {
            val arr = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val block = arr.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isBlank()) AiResult.Err("El proveedor devolvió una respuesta vacía.") else AiResult.Ok(out)
        } catch (e: Exception) {
            AiResult.Err("No pude interpretar la respuesta del proveedor.")
        }
    }
}
