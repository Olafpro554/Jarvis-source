package com.jarvis.maximum.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jarvis.maximum.data.Settings

interface SpeechCallback {
    fun onPartial(text: String) {}
    fun onFinal(text: String)
    fun onError(code: Int, message: String)
}

/**
 * Reconocimiento de voz dentro de la app con android.speech.SpeechRecognizer.
 * No abre ninguna interfaz externa. Debe usarse siempre desde el hilo principal.
 * Nota: el servicio de reconocimiento lo aporta el teléfono (en el Moto G24, normalmente la app de Google);
 * J.A.R.V.I.S. no incluye su propio motor de reconocimiento.
 */
class SpeechManager(private val context: Context, private val settings: Settings) {
    enum class State { IDLE, LISTENING, PROCESSING }

    var state by mutableStateOf(State.IDLE)
        private set
    var partial by mutableStateOf("")
        private set
    var level by mutableStateOf(0f)
        private set

    /** true cuando solo se vigila la palabra de activación (no hay diálogo con el usuario). */
    var passive = false
        private set

    private var recognizer: SpeechRecognizer? = null
    private var callback: SpeechCallback? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun listen(passive: Boolean, cb: SpeechCallback) {
        cancel()
        if (!isAvailable()) {
            cb.onError(-1, "El servicio de reconocimiento de voz no está disponible en este teléfono.")
            return
        }
        this.passive = passive
        callback = cb
        partial = ""
        level = 0f
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = r
            r.setRecognitionListener(listener)
            state = State.LISTENING
            r.startListening(buildIntent())
        } catch (e: Exception) {
            val c = callback
            finish()
            c?.onError(-1, "No pude iniciar el reconocimiento de voz: ${e.message}")
        }
    }

    fun cancel() {
        callback = null
        finish()
    }

    val isActive: Boolean get() = state != State.IDLE

    private fun finish() {
        state = State.IDLE
        level = 0f
        partial = ""
        recognizer?.let {
            runCatching { it.setRecognitionListener(null) }
            runCatching { it.cancel() }
            runCatching { it.destroy() }
        }
        recognizer = null
    }

    private fun buildIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, settings.recognitionLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            if (settings.preferOfflineRecognition) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            val target = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            level = level * 0.6f + target * 0.4f
        }

        override fun onEndOfSpeech() {
            if (!passive && state == State.LISTENING) state = State.PROCESSING
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotBlank()) {
                partial = t
                callback?.onPartial(t)
            }
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            val cb = callback
            callback = null
            finish()
            cb?.onFinal(t)
        }

        override fun onError(error: Int) {
            val cb = callback
            callback = null
            finish()
            cb?.onError(error, describe(error))
        }
    }

    companion object {
        fun describe(code: Int): String = when (code) {
            1 -> "Se agotó el tiempo de red del reconocimiento de voz."
            2 -> "Error de red en el reconocimiento de voz."
            3 -> "Error de audio: no pude usar el micrófono."
            4 -> "El servicio de reconocimiento devolvió un error."
            5 -> "Error interno del reconocimiento de voz."
            6 -> "No escuché nada. ¿Desea intentarlo de nuevo?"
            7 -> "No entendí lo que dijo. ¿Desea repetirlo?"
            8 -> "El reconocimiento de voz está ocupado. Intente de nuevo en un momento."
            9 -> "Falta el permiso del micrófono."
            10 -> "Demasiadas solicitudes de reconocimiento; espere un momento."
            11 -> "El servicio de reconocimiento se desconectó."
            12, 13 -> "El idioma de reconocimiento elegido no está disponible. Cámbielo en Ajustes."
            else -> "Error de reconocimiento de voz ($code)."
        }
    }
}
