package com.jarvis.maximum.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class CoreMode { IDLE, LISTENING, THINKING, SPEAKING }

/** Núcleo holográfico: anillos giratorios, marcas y ondas que reaccionan al micrófono. */
@Composable
fun HoloCore(mode: CoreMode, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "holo")
    val rotA by t.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "a")
    val rotB by t.animateFloat(360f, 0f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "b")
    val pulse by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val phase by t.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "w")
    val smooth by animateFloatAsState(level, tween(120), label = "lvl")

    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = min(size.width, size.height) / 2f
        val center = Offset(cx, cy)

        val amp = when (mode) {
            CoreMode.LISTENING -> 0.12f + smooth * 0.88f
            CoreMode.SPEAKING -> 0.35f + 0.25f * pulse
            CoreMode.THINKING -> 0.22f + 0.12f * sin(phase)
            CoreMode.IDLE -> 0.06f
        }.coerceIn(0f, 1f)

        // Anillo exterior
        drawCircle(
            Holo.Cyan.copy(alpha = 0.25f),
            radius = r * (0.97f + 0.015f * pulse),
            center = center,
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Arcos giratorios
        val ringR = r * 0.88f
        for (i in 0 until 8) {
            drawArc(
                color = Holo.Cyan.copy(alpha = 0.85f),
                startAngle = rotA + i * 45f,
                sweepAngle = 22f,
                useCenter = false,
                topLeft = Offset(cx - ringR, cy - ringR),
                size = Size(ringR * 2f, ringR * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Marcas en sentido contrario
        rotate(rotB, center) {
            for (i in 0 until 72) {
                val a = Math.toRadians(i * 5.0)
                val inner = r * 0.74f
                val outer = r * (if (i % 6 == 0) 0.81f else 0.77f)
                drawLine(
                    Holo.Blue.copy(alpha = 0.6f),
                    Offset(cx + cos(a).toFloat() * inner, cy + sin(a).toFloat() * inner),
                    Offset(cx + cos(a).toFloat() * outer, cy + sin(a).toFloat() * outer),
                    strokeWidth = 1.dp.toPx()
                )
            }
        }

        // Ondas radiales
        val bars = 56
        val speed = if (mode == CoreMode.THINKING) 2f else 1f
        for (i in 0 until bars) {
            val a = i * (2.0 * PI / bars)
            val wobble = 0.5f + 0.5f * sin(phase * speed + i * 0.45f)
            val base = r * 0.50f
            val len = r * (0.04f + 0.20f * amp * wobble)
            drawLine(
                Holo.Cyan.copy(alpha = 0.9f),
                Offset(cx + cos(a).toFloat() * base, cy + sin(a).toFloat() * base),
                Offset(cx + cos(a).toFloat() * (base + len), cy + sin(a).toFloat() * (base + len)),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Núcleo
        val coreR = r * 0.46f * (1f + 0.04f * pulse)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Holo.Cyan.copy(alpha = 0.9f), Holo.Blue.copy(alpha = 0.5f), Color.Transparent),
                center = center,
                radius = coreR
            ),
            radius = coreR,
            center = center
        )
    }
}
