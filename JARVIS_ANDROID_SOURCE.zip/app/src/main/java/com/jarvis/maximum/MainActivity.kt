package com.jarvis.maximum

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.jarvis.maximum.core.JarvisController
import com.jarvis.maximum.core.Screen
import com.jarvis.maximum.ui.MainScreen
import com.jarvis.maximum.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private lateinit var controller: JarvisController
    private var onGranted: (() -> Unit)? = null
    private var onDenied: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val g = onGranted
            val d = onDenied
            onGranted = null
            onDenied = null
            if (granted) g?.invoke() else d?.invoke()
        }

    private val documentLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) controller.summarizeDocument(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        controller = (application as JarvisApp).controller
        controller.requestPermission = { permission, granted, denied -> askPermission(permission, granted, denied) }
        controller.documentPicker = {
            documentLauncher.launch(arrayOf("text/*", "application/json", "application/xml"))
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF36D9FF),
                    secondary = Color(0xFF00A6D6),
                    background = Color(0xFF020812),
                    surface = Color(0xFF071827)
                )
            ) {
                JarvisRoot(controller)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        controller.onUiVisible(true)
    }

    override fun onStop() {
        controller.onUiVisible(false)
        super.onStop()
    }

    override fun onDestroy() {
        controller.requestPermission = null
        controller.documentPicker = null
        super.onDestroy()
    }

    private fun askPermission(permission: String, granted: () -> Unit, denied: () -> Unit) {
        // POST_NOTIFICATIONS solo existe como permiso de ejecución desde Android 13.
        if (permission == Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) {
            granted()
            return
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            granted()
            return
        }
        onGranted = granted
        onDenied = denied
        permissionLauncher.launch(permission)
    }
}

@Composable
private fun JarvisRoot(c: JarvisController) {
    if (c.screen == Screen.SETTINGS) {
        BackHandler { c.screen = Screen.MAIN }
        SettingsScreen(c)
    } else {
        MainScreen(c)
    }
}
