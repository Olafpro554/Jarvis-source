package com.jarvis.maximum.core

import java.text.Normalizer
import java.util.Calendar
import java.util.Locale

/** Utilidades de normalización y análisis de frases en español. */
object Text {
    private val marks = Regex("\\p{M}+")

    /** Minúsculas y sin acentos. Conserva la longitud en casi todos los casos (útil para indexar el original). */
    fun fold(s: String): String =
        marks.replace(Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD), "")

    /** fold + sin signos de puntuación comunes y espacios colapsados. */
    fun clean(s: String): String =
        fold(s)
            .replace(Regex("[¿?¡!,;\"“”]"), " ")
            .replace(Regex("\\.(?=\\s|$)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    enum class Answer { YES, NO, OTHER }

    private val yesWords = setOf(
        "si", "claro", "confirmo", "confirmado", "adelante", "hazlo", "dale", "procede",
        "correcto", "afirmativo", "ok", "okay", "vale", "perfecto", "envialo"
    )
    private val noWords = setOf("no", "cancela", "cancelar", "negativo", "olvidalo", "detente", "mejor no")

    fun answer(input: String): Answer {
        val n = clean(input)
        if (n.isEmpty()) return Answer.OTHER
        val first = n.substringBefore(' ')
        return when {
            n in noWords || first in setOf("no", "cancela", "cancelar", "negativo") -> Answer.NO
            n in yesWords || first in yesWords -> Answer.YES
            else -> Answer.OTHER
        }
    }

    private val numberWords = mapOf(
        "un" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6,
        "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "quince" to 15, "veinte" to 20, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60
    )

    private val durRegex = Regex(
        """\b(\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|doce|quince|veinte|treinta|cuarenta|cincuenta|sesenta)\s+(horas?|minutos?|mins?|segundos?|segs?)\b"""
    )

    /** "5 minutos", "1 hora 30 minutos", "media hora" → segundos. */
    fun parseDurationSeconds(n: String): Int? {
        var total = 0
        var found = false
        for (m in durRegex.findAll(n)) {
            val raw = m.groupValues[1]
            val v = raw.toIntOrNull() ?: numberWords[raw] ?: continue
            val unit = m.groupValues[2]
            total += when {
                unit.startsWith("h") -> v * 3600
                unit.startsWith("m") -> v * 60
                else -> v
            }
            found = true
        }
        if (Regex("""\bhoras? y media\b""").containsMatchIn(n) || Regex("""\bmedia hora\b""").containsMatchIn(n)) {
            total += 1800
            found = true
        }
        return if (found && total > 0) total else null
    }

    /** Regex de "en 20 minutos" para poder quitarlo del texto del recordatorio. */
    val relativeDurationRegex = Regex(
        """\ben\s+(?:\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|doce|quince|veinte|treinta|cuarenta|cincuenta|sesenta)\s+(?:horas?|minutos?|mins?|segundos?|segs?)(?:\s+y media)?\b|\ben\s+media hora\b"""
    )

    data class TimeOfDay(val hour: Int, val minute: Int, val range: IntRange)

    private val timeRegex = Regex(
        """\b(?:a la|a las)\s+(\d{1,2}|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce)(?:[:.](\d{2}))?(?:\s+(y media|y cuarto|menos cuarto|en punto|y (\d{1,2})))?(?:\s+(?:de la|del|por la|de)\s+(manana|tarde|noche|madrugada|mediodia))?"""
    )

    /** "a las 7 y media de la tarde" → 19:30. Sin periodo, elige la próxima ocurrencia. */
    fun parseTimeOfDay(n: String, now: Calendar = Calendar.getInstance()): TimeOfDay? {
        val m = timeRegex.find(n) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: numberWords[m.groupValues[1]] ?: return null
        var min = m.groupValues[2].toIntOrNull() ?: 0
        val mod = m.groupValues[3]
        when {
            mod == "y media" -> min = 30
            mod == "y cuarto" -> min = 15
            mod == "menos cuarto" -> {
                h -= 1
                min = 45
            }
            m.groupValues[4].isNotEmpty() -> min = m.groupValues[4].toInt()
        }
        if (h < 0) h += 24
        if (min > 59 || h > 24) return null
        when (m.groupValues[5]) {
            "manana", "madrugada" -> if (h == 12) h = 0
            "tarde" -> if (h < 12) h += 12
            "noche" -> {
                if (h < 12) h += 12
                if (h == 12) h = 0
            }
            "mediodia" -> h = 12
            else -> {
                if (h in 1..12) {
                    val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                    val am = (h % 12) * 60 + min
                    val pm = am + 12 * 60
                    h = when {
                        am > nowMin -> am / 60
                        pm > nowMin -> pm / 60
                        else -> am / 60
                    }
                }
            }
        }
        return TimeOfDay(h % 24, min, m.range)
    }

    /** Resto del texto original tras una coincidencia hecha sobre su versión `fold`. */
    fun tail(original: String, folded: String, endInclusive: Int): String {
        val src = if (original.length == folded.length) original else folded
        return src.substring((endInclusive + 1).coerceAtMost(src.length)).trim()
    }
}

/** Detección de la palabra de activación con variantes fonéticas habituales del reconocedor. */
object WakeWord {
    val jarvisVariants = listOf(
        "jarvis", "yarvis", "charvis", "jarbis", "yarbis", "harvis", "jarvi", "yarvi",
        "jarvins", "jarvice", "yervis", "jervis", "garvis", "jarves", "jarbi"
    )

    fun normalizedWord(configured: String): String =
        Text.fold(configured).filter { it.isLetterOrDigit() || it == ' ' }.trim().ifBlank { "jarvis" }

    fun names(configured: String): List<String> {
        val w = normalizedWord(configured)
        return if (w == "jarvis") jarvisVariants else listOf(w)
    }

    /** Devuelve lo que se dijo después de la palabra de activación, o null si no se dijo. */
    fun extract(heard: String, configured: String): String? {
        val f = Text.fold(heard)
        val alt = names(configured).joinToString("|") { Regex.escape(it) }
        val m = Regex("""\b(?:$alt)\b""").find(f) ?: return null
        return Text.tail(heard, f, m.range.last).trimStart(',', '.', ':', ';', '!', '¡', '?', '¿', ' ')
    }
}
