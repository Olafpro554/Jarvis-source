package com.jarvis.maximum.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.maximum.core.AiState
import com.jarvis.maximum.core.JarvisController
import com.jarvis.maximum.core.PendingAction
import com.jarvis.maximum.core.Screen
import com.jarvis.maximum.data.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainScreen(c: JarvisController) {
    var input by remember { mutableStateOf("") }
    val bg = Brush.verticalGradient(listOf(Holo.Bg0, Holo.Bg1, Holo.Bg2))
    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 14.dp)
    ) {
        TopBar(c)
        StatusRow(c)
        CoreSection(c)
        ConversationPanel(c, Modifier.weight(1f).fillMaxWidth())
        InputBar(c, input, { input = it }) {
            if (input.isNotBlank()) {
                c.submit(input)
                input = ""
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun TopBar(c: JarvisController) {
    val clockFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEE d MMM", Locale("es", "PE")) }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                c.settings.assistantName.uppercase(),
                color = Holo.Cyan2, fontSize = 21.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val now = Date(c.clockMillis)
            Text(
                clockFmt.format(now) + "  •  " + dateFmt.format(now),
                color = Holo.Dim, fontSize = 11.sp, letterSpacing = 1.sp
            )
        }
        IconButton(onClick = { c.newConversation() }) {
            Icon(Icons.Default.Add, contentDescription = "Nueva conversación", tint = Holo.Cyan)
        }
        IconButton(onClick = { c.documentPicker?.invoke() }) {
            Icon(Icons.Default.AttachFile, contentDescription = "Resumir un documento de texto", tint = Holo.Cyan)
        }
        IconButton(onClick = { c.screen = Screen.SETTINGS }) {
            Icon(Icons.Default.Settings, contentDescription = "Ajustes", tint = Holo.Cyan)
        }
    }
}

@Composable
private fun StatusRow(c: JarvisController) {
    val net = if (c.online) Pair("EN LÍNEA", Holo.Ok) else Pair("SIN RED", Holo.Warn)
    val aiv = when (c.aiState) {
        AiState.READY -> Pair("LISTA", Holo.Ok)
        AiState.NOT_CONFIGURED -> Pair("SIN CONFIG.", Holo.Warn)
        AiState.OFFLINE -> Pair("SIN RED", Holo.Warn)
        AiState.ERROR -> Pair("ERROR", Holo.Err)
    }
    val listening = c.speech.isActive && !c.speech.passive
    val mic = when {
        listening -> Pair("ESCUCHANDO", Holo.Cyan)
        c.wakeActive -> Pair("VIGILANDO", Holo.Cyan2)
        !c.hasMic() -> Pair("SIN PERMISO", Holo.Warn)
        else -> Pair("EN ESPERA", Holo.Dim)
    }
    val low = c.batteryPercent < 15 && !c.charging
    val bat = Pair("${c.batteryPercent}%" + if (c.charging) " ⚡" else "", if (low) Holo.Err else Holo.Ok)

    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StatusChip("CONEXIÓN", net.first, net.second, Modifier.weight(1f))
        StatusChip("IA", aiv.first, aiv.second, Modifier.weight(1f))
        StatusChip("MICRÓFONO", mic.first, mic.second, Modifier.weight(1f))
        StatusChip("BATERÍA", bat.first, bat.second, Modifier.weight(1f))
    }
}

@Composable
private fun StatusChip(label: String, value: String, color: Color, modifier: Modifier) {
    Column(
        modifier
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(horizontal = 4.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Holo.Dim, fontSize = 8.sp, letterSpacing = 1.sp, maxLines = 1)
        Text(value, color = color, fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CoreSection(c: JarvisController) {
    val listening = c.speech.isActive && !c.speech.passive
    val mode = when {
        listening -> CoreMode.LISTENING
        c.busy -> CoreMode.THINKING
        c.tts.speaking -> CoreMode.SPEAKING
        else -> CoreMode.IDLE
    }
    val caption = when {
        listening && c.speech.partial.isNotBlank() -> "“" + c.speech.partial + "”"
        listening -> "Escuchando…"
        c.busy -> "Procesando…"
        c.tts.speaking -> "Hablando…"
        c.wakeActive -> c.wakeStatus
        else -> "En espera. Toque el núcleo para hablar."
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(180.dp).clip(CircleShape).clickable { c.toggleListening() },
            contentAlignment = Alignment.Center
        ) {
            HoloCore(mode, c.speech.level, Modifier.fillMaxSize())
            Text("J", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraLight)
        }
        Text(
            caption, color = Holo.Text, fontSize = 13.sp, textAlign = TextAlign.Center,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp)
        )
        val msg = c.listenMessage
        if (msg != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(msg, color = Holo.Warn, fontSize = 12.sp, modifier = Modifier.weight(1f, fill = false))
                TextButton(onClick = { c.startListening() }) { Text("Repetir", color = Holo.Cyan) }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun ConversationPanel(c: JarvisController, modifier: Modifier) {
    val msgs = c.memory.messages.filter { it.conv == c.memory.currentConv }
    val state = rememberLazyListState()
    val count = msgs.size + (if (c.busy) 1 else 0) + (if (c.pending != null) 1 else 0)
    LaunchedEffect(count) {
        if (count > 0) state.animateScrollToItem(count - 1)
    }
    Box(
        modifier
            .border(1.dp, Holo.Cyan.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
            .background(Color(0x66061B2B), RoundedCornerShape(16.dp))
            .padding(10.dp)
    ) {
        LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
            if (msgs.isEmpty()) item { Hint(c) }
            items(msgs) { m -> Bubble(m) }
            if (c.busy) item { Text("Pensando…", color = Holo.Dim, fontSize = 13.sp) }
            val p = c.pending
            if (p != null) item { PendingCard(c, p) }
        }
    }
}

@Composable
private fun Hint(c: JarvisController) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Sistemas en línea. Escriba una orden o toque el núcleo para hablar.", color = Holo.Text, fontSize = 13.sp)
        if (c.aiState == AiState.NOT_CONFIGURED) {
            Text(
                "La inteligencia artificial aún no está configurada, así que funciono en modo local: " +
                    "abrir apps, hora, batería, alarmas, llamadas y mensajes. Diga «ayuda» para ver todo.",
                color = Holo.Warn, fontSize = 12.sp
            )
            TextButton(onClick = { c.screen = Screen.SETTINGS }) { Text("Configurar IA en Ajustes", color = Holo.Cyan) }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val user = m.role == "user"
    val sys = m.role == "system"
    val bg = when {
        user -> Color(0x330879B4)
        sys -> Color(0x33FFB84D)
        else -> Color(0x1A36D9FF)
    }
    val border = when {
        user -> Holo.Blue.copy(alpha = 0.5f)
        sys -> Holo.Warn.copy(alpha = 0.5f)
        else -> Holo.Cyan.copy(alpha = 0.4f)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .background(bg, RoundedCornerShape(14.dp))
                .border(1.dp, border, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            SelectionContainer {
                Text(m.text, color = Holo.Text, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}

@Composable
private fun PendingCard(c: JarvisController, p: PendingAction) {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Holo.Warn.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            .background(Color(0x22FFB84D), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("CONFIRMACIÓN REQUERIDA", color = Holo.Warn, fontSize = 10.sp, letterSpacing = 2.sp)
        Text(p.title, color = Holo.Text, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { c.confirmPending(true) }) { Text("Confirmar") }
            OutlinedButton(onClick = { c.confirmPending(false) }) { Text("Cancelar") }
        }
    }
}

@Composable
private fun InputBar(c: JarvisController, value: String, onChange: (String) -> Unit, onSend: () -> Unit) {
    val listening = c.speech.isActive && !c.speech.passive
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Escriba una orden…", color = Holo.Dim) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            trailingIcon = {
                IconButton(onClick = onSend) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar", tint = Holo.Cyan)
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Holo.Cyan,
                unfocusedBorderColor = Color(0x6646BBD8),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = Holo.Cyan
            )
        )
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(if (listening) Holo.Err.copy(alpha = 0.85f) else Color(0xFF087DAA))
                .clickable { c.toggleListening() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (listening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (listening) "Cancelar escucha" else "Hablar",
                tint = Color.White
            )
        }
    }
}
