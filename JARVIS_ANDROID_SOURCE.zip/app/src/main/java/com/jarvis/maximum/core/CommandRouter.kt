package com.jarvis.maximum.core

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings as Sys
import com.jarvis.maximum.phone.ConnType
import com.jarvis.maximum.phone.ContactMatch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Acción sensible que espera confirmación explícita del usuario. */
class PendingAction(val title: String, val onConfirm: () -> String)

class Routed(
    val reply: String,
    val pending: PendingAction? = null,
    val needsPermission: String? = null,
    val speak: Boolean = true
)

/**
 * Comandos locales: funcionan sin Internet. Si una orden no es un comando conocido devuelve null
 * y el controlador la pasa a la IA (o al modo sin conexión).
 */
class CommandRouter(private val c: JarvisController) {
    private val s get() = c.settings

    fun route(input: String): Routed? {
        val o = stripWake(input.trim())
        val f = Text.fold(o)
        val n = Text.clean(o)
        if (n.isBlank()) return Routed("Dígame, le escucho.")

        if (n in setOf("silencio", "callate", "detente", "para", "basta", "alto")) {
            c.tts.stop()
            return Routed("Silencio.", speak = false)
        }

        // --- Información local ---
        if (Regex("""\bque hora es\b|\bdime la hora\b|^la hora$|\bhora actual\b""").containsMatchIn(n)) {
            return Routed(timeText())
        }
        if (Regex("""\bque (?:dia|fecha) (?:es|tenemos)\b|\bfecha de hoy\b|\bdia es hoy\b|^la fecha$""").containsMatchIn(n)) {
            val fmt = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "PE"))
            return Routed("Hoy es ${fmt.format(Date())}.")
        }

        // --- Ajustes del teléfono / de J.A.R.V.I.S. ---
        Regex("""^(?:abre|abrir|abri|muestra|ve a|ir a)\s+(?:los |las |el |la )?(?:ajustes|configuracion)(?:\s+(?:de|del)\s+(.+))?$""")
            .find(n)?.let { return settingsCommand(it.groupValues[1].trim()) }

        if (Regex("""\b(?:bateria|carga)\b""").containsMatchIn(n) &&
            Regex("""\b(?:cuanta|cuanto|que|nivel|estado|como esta|tengo|queda|porcentaje)\b""").containsMatchIn(n)
        ) {
            val p = c.phone.batteryPercent()
            val ch = if (c.phone.isCharging()) "y se está cargando" else "y no se está cargando"
            return Routed("La batería está al $p por ciento $ch.")
        }

        if (Regex("""\b(?:estoy conectado|tengo internet|hay internet|estado de (?:la )?(?:red|conexion)|conexion a internet|estoy en linea)\b""").containsMatchIn(n)) {
            val txt = when (c.phone.connectionType()) {
                ConnType.NONE -> "No hay ninguna red activa. Estoy en modo sin conexión."
                ConnType.WIFI -> if (c.online) "Conectado por Wi-Fi, con acceso a Internet." else "Conectado a una red Wi-Fi, pero sin acceso a Internet."
                ConnType.MOBILE -> if (c.online) "Conectado por datos móviles, con acceso a Internet." else "Datos móviles activos, pero sin acceso a Internet."
                ConnType.OTHER -> if (c.online) "Conectado a Internet." else "Red activa, pero sin acceso a Internet."
            }
            return Routed(txt)
        }

        if (Regex("""informacion del (?:dispositivo|telefono|celular|equipo)|datos del (?:telefono|celular|dispositivo)|que telefono (?:tengo|es)|especificaciones|cuanta (?:memoria|ram|almacenamiento)""")
                .containsMatchIn(n)
        ) return Routed(c.phone.deviceInfo())

        // --- Volumen ---
        if ("volumen" in n) volumeCommand(n)?.let { return it }

        // --- Alarmas, temporizadores y recordatorios ---
        if (Regex("""\b(?:elimina|borra|cancela|quita)\b.*\b(?:alarma|temporizador|recordatorio)""").containsMatchIn(n)) {
            return Routed("No puedo borrar alarmas ni temporizadores por usted; Android no me lo permite. Puede hacerlo desde la aplicación Reloj.")
        }
        if (Regex("""\balarma\b|\bdespiertame\b""").containsMatchIn(n)) return alarm(n)
        if (Regex("""\b(?:temporizador|cuenta atras|timer)\b""").containsMatchIn(n)) {
            val sec = Text.parseDurationSeconds(n) ?: return Routed("¿De cuánto tiempo? Por ejemplo: «temporizador de 10 minutos».")
            return timer(sec, "J.A.R.V.I.S.")
        }
        Regex("""^(?:recuerdame|recordarme|ponme un recordatorio|crea un recordatorio|crear recordatorio|recordatorio)\b(.*)$""")
            .find(n)?.let { return reminder(n, it.groupValues[1]) }

        // --- Memoria y asistente ---
        memoryCommand(o, f, n)?.let { return it }

        // --- Teléfono, llamadas y mensajes ---
        if (Regex("""^(?:abre|abrir|abri|muestra)\s+(?:el |la )?(?:marcador|teclado telefonico|teclado del telefono|dialer)$""").containsMatchIn(n)) {
            return Routed(c.launch(listOf(Intent(Intent.ACTION_DIAL)), "He abierto el marcador telefónico.", "abrir el marcador"))
        }
        messageCommand(o, f, n)?.let { return it }
        callCommand(n)?.let { return it }
        contactSearch(n)?.let { return it }

        // --- Abrir aplicaciones (siempre al final de los comandos de «abre») ---
        openApp(n)?.let { return it }

        return null
    }

    // ------------------------------------------------------------------

    private fun stripWake(o: String): String {
        val f = Text.fold(o)
        val alt = WakeWord.names(s.wakeWord).joinToString("|") { Regex.escape(it) }
        val m = Regex("""^(?:(?:hey|oye|ok|okay|hola)\s+)?(?:$alt)\b[\s,.:;!¡]*""").find(f) ?: return o
        return Text.tail(o, f, m.range.last)
    }

    private fun timeText(): String {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val period = when (h) {
            in 0..5 -> "de la madrugada"
            in 6..11 -> "de la mañana"
            12 -> "del mediodía"
            in 13..18 -> "de la tarde"
            else -> "de la noche"
        }
        val verb = if (h12 == 1) "Es la" else "Son las"
        return if (m == 0) "$verb $h12 en punto $period." else "$verb $h12 y ${"%02d".format(m)} $period."
    }

    private fun settingsCommand(sub: String): Routed {
        if (sub.isNotEmpty() && Regex("""jarvis|asistente|tus|tu |maximum""").containsMatchIn(sub)) {
            return Routed(c.openJarvisSettings())
        }
        val action = when {
            sub.isEmpty() -> Sys.ACTION_SETTINGS
            "wifi" in sub || "wi fi" in sub -> Sys.ACTION_WIFI_SETTINGS
            "bluetooth" in sub -> Sys.ACTION_BLUETOOTH_SETTINGS
            "sonido" in sub || "volumen" in sub -> Sys.ACTION_SOUND_SETTINGS
            "pantalla" in sub || "brillo" in sub -> Sys.ACTION_DISPLAY_SETTINGS
            "bateria" in sub -> Sys.ACTION_BATTERY_SAVER_SETTINGS
            "aplicaciones" in sub || "apps" in sub -> Sys.ACTION_APPLICATION_SETTINGS
            "ubicacion" in sub || "gps" in sub -> Sys.ACTION_LOCATION_SOURCE_SETTINGS
            "fecha" in sub || "hora" in sub -> Sys.ACTION_DATE_SETTINGS
            "avion" in sub -> Sys.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Sys.ACTION_SETTINGS
        }
        return Routed(c.launch(listOf(Intent(action)), "Abriendo los ajustes del teléfono.", "abrir los ajustes"))
    }

    private fun volumeCommand(n: String): Routed? {
        val pct = Regex("""(\d{1,3})\s*(?:%|por ciento)""").find(n)?.groupValues?.get(1)?.toIntOrNull()
        return when {
            pct != null -> {
                c.phone.setVolumePercent(pct)
                Routed("Volumen multimedia al ${c.phone.volumePercent()} por ciento.")
            }
            Regex("""\b(?:maximo|al maximo|a tope)\b""").containsMatchIn(n) -> {
                c.phone.setVolumePercent(100)
                Routed("Volumen multimedia al máximo.")
            }
            Regex("""\b(?:minimo|al minimo|silencio)\b""").containsMatchIn(n) -> {
                c.phone.setVolumePercent(0)
                Routed("Volumen multimedia al mínimo.")
            }
            Regex("""\b(?:sube|subir|aumenta|aumentar|mas alto|eleva)\b""").containsMatchIn(n) -> {
                c.phone.adjustVolume(true)
                Routed("Volumen multimedia al ${c.phone.volumePercent()} por ciento.")
            }
            Regex("""\b(?:baja|bajar|reduce|reducir|disminuye|mas bajo)\b""").containsMatchIn(n) -> {
                c.phone.adjustVolume(false)
                Routed("Volumen multimedia al ${c.phone.volumePercent()} por ciento.")
            }
            Regex("""\bcual es\b|\bque volumen\b|\bnivel\b""").containsMatchIn(n) ->
                Routed("El volumen multimedia está al ${c.phone.volumePercent()} por ciento.")
            else -> null
        }
    }

    private fun hhmm(h: Int, m: Int) = "%02d:%02d".format(h, m)

    private fun alarm(n: String): Routed {
        val t = Text.parseTimeOfDay(n)
            ?: return Routed("¿A qué hora desea la alarma? Por ejemplo: «pon una alarma a las 7 y media de la mañana».")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, t.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, t.minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "J.A.R.V.I.S.")
        val hm = hhmm(t.hour, t.minute)
        return Routed(
            c.launch(
                listOf(i),
                "He abierto el Reloj con una alarma preparada para las $hm. Compruebe allí que quedó activada.",
                "crear la alarma de las $hm"
            )
        )
    }

    private fun timer(seconds: Int, message: String): Routed {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, message)
        val txt = when {
            seconds >= 3600 && seconds % 3600 == 0 -> "${seconds / 3600} h"
            seconds >= 60 && seconds % 60 == 0 -> "${seconds / 60} min"
            else -> "$seconds s"
        }
        return Routed(
            c.launch(
                listOf(i),
                "He abierto el Reloj con un temporizador de $txt. Compruebe allí que está en marcha.",
                "crear el temporizador de $txt"
            )
        )
    }

    private fun reminder(n: String, rest: String): Routed {
        // Con hora concreta -> alarma con mensaje; con "en N minutos" -> temporizador con mensaje.
        val absT = Text.parseTimeOfDay(n)
        val rel = Text.relativeDurationRegex.find(n)
        var text = rest
        val absRest = Text.parseTimeOfDay(rest)
        if (absRest != null) text = text.removeRange(absRest.range)
        if (rel != null) text = text.replace(rel.value, " ")
        text = text.replace(Regex("""^\s*(?:que|de|a)\s+"""), "").replace(Regex("\\s+"), " ").trim()
        val msg = text.ifBlank { "Recordatorio" }
        val relSeconds = rel?.let { Text.parseDurationSeconds(it.value) }
        return when {
            absT != null -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, absT.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, absT.minute)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, msg)
                val hm = hhmm(absT.hour, absT.minute)
                Routed(
                    c.launch(
                        listOf(i),
                        "He preparado en el Reloj un recordatorio para las $hm: «$msg». Compruebe allí que quedó activado.",
                        "crear el recordatorio de las $hm"
                    )
                )
            }
            relSeconds != null -> timer(relSeconds, msg)
            else -> Routed("¿Para cuándo? Por ejemplo: «recuérdame llamar a mi madre a las 5 de la tarde» o «recuérdame sacar la ropa en 20 minutos».")
        }
    }

    // ------------------------------------------------------------------ Memoria

    private fun memoryCommand(o: String, f: String, n: String): Routed? {
        Regex("""^(?:me llamo|mi nombre es|llamame)\s+""").find(f)?.let {
            val name = Text.tail(o, f, it.range.last).trim(' ', '.', ',')
            if (name.isBlank()) return null
            if (!s.memoryEnabled) return Routed("La memoria está desactivada, así que no guardaré su nombre. Puede activarla en Ajustes.")
            s.userName = name
            c.memory.addFact("El usuario se llama $name")
            return Routed("Encantado, $name. Lo recordaré.")
        }
        Regex("""^(?:tu nombre sera|te llamaras|llamate|tu nombre es|a partir de ahora te llamas)\s+""").find(f)?.let {
            val name = Text.tail(o, f, it.range.last).trim(' ', '.', ',')
            if (name.isBlank()) return null
            s.assistantName = name
            return Routed("De acuerdo. A partir de ahora me presentaré como $name. La palabra de activación sigue siendo «${s.wakeWord}»; puede cambiarla en Ajustes.")
        }
        Regex("""^recuerda que\s+""").find(f)?.let {
            val fact = Text.tail(o, f, it.range.last).trim(' ', '.', ',')
            if (fact.isBlank()) return null
            return if (c.memory.addFact(fact)) Routed("Anotado: $fact.")
            else Routed("La memoria está desactivada, no puedo guardar eso. Puede activarla en Ajustes.")
        }
        Regex("""^(?:olvida que|olvidate de que|olvida lo de)\s+""").find(f)?.let {
            val term = Text.tail(o, f, it.range.last).trim(' ', '.', ',')
            if (term.isBlank()) return null
            val removed = c.memory.removeFactsContaining(term)
            return Routed(if (removed > 0) "Hecho. He olvidado $removed dato(s) que mencionaban «$term»." else "No tenía guardado nada que mencionara «$term».")
        }
        if (Regex("""\bcomo me llamo\b|\bcual es mi nombre\b|\bsabes mi nombre\b""").containsMatchIn(n)) {
            return Routed(
                if (s.userName.isNotBlank() && s.memoryEnabled) "Se llama ${s.userName}."
                else "Todavía no me ha dicho su nombre. Puede decir: «me llamo…»."
            )
        }
        if (Regex("""\bque recuerdas\b|\bque sabes de mi\b|\bque guardas de mi\b""").containsMatchIn(n)) {
            val facts = c.memory.activeFacts()
            return Routed(
                if (!s.memoryEnabled) "La memoria está desactivada."
                else if (facts.isEmpty()) "No tengo datos suyos guardados."
                else "Esto es lo que tengo guardado: " + facts.joinToString("; ") + "."
            )
        }
        if (Regex("""^(?:olvida todo|borra (?:toda )?la memoria|borra mi memoria|borra (?:mi |el )?historial|elimina (?:toda )?la memoria|olvidalo todo)$""").containsMatchIn(n)) {
            return Routed(
                "Esto borrará el historial y todo lo que he guardado de usted. ¿Confirma?",
                pending = PendingAction("Borrar toda la memoria") {
                    c.memory.clearAll()
                    "Memoria borrada por completo."
                }
            )
        }
        if (Regex("""^(?:nueva conversacion|cambiemos de tema|otro tema|empecemos de nuevo|empezar de nuevo|borron y cuenta nueva)$""").containsMatchIn(n)) {
            c.memory.newConversation()
            return Routed("Empezamos una conversación nueva.")
        }
        if (Regex("""^(?:desactiva|apaga|deshabilita) (?:la )?memoria$""").containsMatchIn(n)) {
            s.memoryEnabled = false
            c.memory.onEnabledChanged(false)
            return Routed("Memoria desactivada. No guardaré ni usaré datos de conversaciones.")
        }
        if (Regex("""^(?:activa|enciende|habilita) (?:la )?memoria$""").containsMatchIn(n)) {
            s.memoryEnabled = true
            c.memory.onEnabledChanged(true)
            return Routed("Memoria activada.")
        }
        if (Regex("""\bestado de (?:la )?(?:ia|inteligencia artificial|sistema)\b|\bia esta (?:lista|conectada)\b""").containsMatchIn(n)) {
            return Routed(c.aiStatusText())
        }
        if (Regex("""^(?:que puedes hacer|ayuda|comandos|que funciones tienes|que sabes hacer)$""").containsMatchIn(n)) {
            return Routed(capabilities())
        }
        return null
    }

    fun capabilities(): String =
        "Puedo: abrir aplicaciones; decir la hora, la fecha, la batería y el estado de la conexión; subir o bajar el volumen; " +
            "crear alarmas, temporizadores y recordatorios en el Reloj; buscar contactos, y preparar llamadas, SMS y mensajes de WhatsApp " +
            "(siempre con su confirmación, y usted pulsa enviar o llamar); y recordar datos que me pida. " +
            "Con una IA configurada y conexión a Internet también converso, explico, traduzco, resumo textos y ayudo a programar."

    // ------------------------------------------------------------------ Llamadas y mensajes

    private fun permissionNeeded(): Routed =
        Routed("Necesito permiso para leer sus contactos.", needsPermission = Manifest.permission.READ_CONTACTS)

    private fun pickContact(query: String, then: (ContactMatch) -> Routed): Routed {
        if (!c.phone.hasContactsPermission()) return permissionNeeded()
        val matches = c.phone.searchContacts(query)
        if (matches.isEmpty()) return Routed("No encontré ningún contacto que coincida con «$query».")
        val names = matches.map { it.name }.distinct()
        val exact = names.firstOrNull { Text.clean(it) == Text.clean(query) }
        if (names.size > 1 && exact == null) {
            return Routed("Encontré varios contactos: ${names.take(4).joinToString(", ")}. Indíqueme el nombre completo.")
        }
        val chosen = exact ?: names.first()
        return then(matches.first { it.name == chosen })
    }

    private fun digitsOnly(q: String): String? {
        val d = q.filter { it.isDigit() || it == '+' }
        return if (d.count { it.isDigit() } >= 6 && q.all { it.isDigit() || it == '+' || it == ' ' || it == '-' }) d else null
    }

    private fun callCommand(n: String): Routed? {
        val m = Regex("""^(?:llama|llamar|llamale|marca|marcar|marcale|telefonea)\s+(?:a la |al |a |el numero |el )?(.+)$""").find(n) ?: return null
        val target = m.groupValues[1].trim()
        val direct = digitsOnly(target)
        if (direct != null) return callPending(direct, direct)
        return pickContact(target) { ct -> callPending(ct.name, ct.number) }
    }

    private fun callPending(label: String, number: String): Routed =
        Routed(
            "¿Desea que prepare una llamada a $label? Abriré el marcador con el número y usted pulsará llamar.",
            pending = PendingAction("Preparar llamada a $label ($number)") {
                c.launch(
                    listOf(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))),
                    "He abierto el marcador con el número de $label. Todavía no he llamado: pulse llamar para iniciar la llamada.",
                    "abrir el marcador con el número de $label"
                )
            }
        )

    private fun contactSearch(n: String): Routed? {
        val m = Regex("""^(?:busca|buscar|encuentra)\s+(?:el |al )?(?:contacto|numero)\s+(?:de |del )?(.+)$|^(?:numero|telefono) de (.+)$""").find(n) ?: return null
        val q = (m.groupValues[1].ifBlank { m.groupValues[2] }).trim()
        if (!c.phone.hasContactsPermission()) return permissionNeeded()
        val matches = c.phone.searchContacts(q)
        if (matches.isEmpty()) return Routed("No encontré ningún contacto que coincida con «$q».")
        val txt = matches.distinctBy { it.name + it.number }.take(4).joinToString("; ") { "${it.name}: ${it.number}" }
        return Routed("Encontré: $txt.")
    }

    private fun messageCommand(o: String, f: String, n: String): Routed? {
        val wa = Regex("""\b(?:whatsapp|wasap|guasap|whats app)\b""").containsMatchIn(n)
        val sms = Regex("""\bsms\b|\bmensaje de texto\b""").containsMatchIn(n)
        val send = Regex("""^(?:manda|mandale|mandar|envia|enviale|enviar|dile|dejale)\b""").containsMatchIn(n)
        val draft = Regex("""^(?:escribe|escribele|escribir|prepara|redacta|abre|abrir|abri)\b""").containsMatchIn(n)
        if (!wa && !sms) {
            // «mándale un mensaje a Juan» sin canal: preguntar. Los borradores («escribe un mensaje…») van a la IA.
            return if (send && "mensaje" in n) Routed("¿Lo envío por WhatsApp o por SMS? Repita la orden indicando el canal.") else null
        }
        if (!send && !draft) return null

        val nameRe = Regex("""\b(?:a|para|con)\s+(?:mi\s+|mis\s+|el\s+|la\s+)?([a-z0-9+ ]+?)(?=\s+(?:diciendo|que|con el mensaje|con el texto|por|en|de whatsapp)\b|[,:]|$)""")
        val nm = nameRe.find(f)
        if (nm == null) {
            return if (Regex("""^(?:abre|abrir|abri)\b""").containsMatchIn(n)) null
            else Routed("¿A quién? Por ejemplo: «mándale un WhatsApp a Juan diciendo que llego tarde».")
        }
        val who = nm.groupValues[1].trim()

        // Cuerpo del mensaje: lo que sigue a "diciendo", "que diga", ":" etc. (con el texto original).
        val restStart = nm.groups[1]!!.range.last + 1
        val restF = f.substring(restStart)
        val bm = Regex("""^[\s,]*(?:(?:por|en|de) (?:whatsapp|sms|mensaje)\s*)?(?:diciendo|que diga|que dice|que le diga|que le digas|con el mensaje|con el texto|que|:)\s*:?\s*(.+)$""").find(restF)
        val body = if (bm != null) {
            val idx = restStart + bm.groups[1]!!.range.first
            (if (o.length == f.length) o.substring(idx) else f.substring(idx)).trim().trim('"', '“', '”')
        } else ""

        val direct = digitsOnly(who)
        return if (direct != null) messagePending(wa, who, direct, null, body)
        else pickContact(who) { ct -> messagePending(wa, ct.name, ct.number, ct.normalized, body) }
    }

    private fun waNumber(number: String, normalized: String?): String {
        if (!normalized.isNullOrBlank()) return normalized.filter { it.isDigit() }
        val d = number.filter { it.isDigit() }
        if (number.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        val cc = s.countryCode.filter { it.isDigit() }
        return if (cc.isNotEmpty() && d.length <= 10) cc + d.trimStart('0') else d
    }

    private fun messagePending(wa: Boolean, label: String, number: String, normalized: String?, body: String): Routed {
        val shown = if (body.isBlank()) "sin texto (solo abriré la conversación)" else "con el texto: «$body»"
        return if (wa) {
            val num = waNumber(number, normalized)
            val url = "https://wa.me/$num" + if (body.isNotBlank()) "?text=${Uri.encode(body)}" else ""
            val base = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            val intents = listOf(
                Intent(base).setPackage("com.whatsapp"),
                Intent(base).setPackage("com.whatsapp.w4b"),
                Intent(base)
            )
            Routed(
                "¿Preparo un mensaje de WhatsApp para $label $shown? No lo enviaré: usted debe pulsar enviar en WhatsApp.",
                pending = PendingAction("WhatsApp para $label") {
                    c.launch(
                        intents,
                        "He abierto WhatsApp con el mensaje preparado para $label. Todavía no se ha enviado: pulse enviar en WhatsApp.",
                        "abrir WhatsApp con el mensaje para $label"
                    )
                }
            )
        } else {
            val num = number.filter { it.isDigit() || it == '+' }
            val i = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", num, null)).putExtra("sms_body", body)
            Routed(
                "¿Preparo un SMS para $label $shown? No lo enviaré: usted debe pulsar enviar.",
                pending = PendingAction("SMS para $label") {
                    c.launch(
                        listOf(i),
                        "He abierto la aplicación de mensajes con el SMS preparado para $label. Todavía no se ha enviado: pulse enviar.",
                        "abrir mensajes con el SMS para $label"
                    )
                }
            )
        }
    }

    // ------------------------------------------------------------------ Aplicaciones

    private fun openApp(n: String): Routed? {
        val m = Regex("""^(?:abre|abrir|abri|inicia|iniciar|lanza|lanzar|ejecuta|ejecutar|open)\s+(?:la |el |las |los )?(?:app |aplicacion )?(?:de )?(.+)$""").find(n) ?: return null
        val q = m.groupValues[1].trim()
        if (q.isBlank()) return null
        val apps = c.phone.launchableApps().map { it to Text.fold(it.label) }
        val hit = apps.firstOrNull { it.second == q }
            ?: apps.filter { it.second.startsWith(q) }.minByOrNull { it.second.length }
            ?: apps.filter { it.second.contains(q) }.minByOrNull { it.second.length }
            ?: apps.filter { it.second.length >= 3 && q.contains(it.second) }.maxByOrNull { it.second.length }
            ?: return Routed("No encuentro ninguna aplicación instalada llamada «$q».")
        val label = hit.first.label
        val intent = c.phone.launchIntent(hit.first.pkg) ?: return Routed("No puedo abrir $label.")
        return Routed(c.launch(listOf(intent), "Abriendo $label.", "abrir $label"))
    }
}
