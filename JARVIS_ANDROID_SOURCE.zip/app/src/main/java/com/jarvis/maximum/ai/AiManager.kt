package com.jarvis.maximum.ai

import com.jarvis.maximum.data.SecureStore
import com.jarvis.maximum.data.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Decide si hay IA utilizable, construye el proveedor y el mensaje de sistema. */
class AiManager(private val settings: Settings, private val secure: SecureStore) {

    fun defaultBase(provider: String): String = when (provider) {
        "openai" -> "https://api.openai.com/v1"
        "anthropic" -> "https://api.anthropic.com/v1"
        else -> ""
    }

    fun effectiveBase(): String = settings.aiBaseUrl.trim().ifBlank { defaultBase(settings.aiProvider) }

    private fun needsKey(): Boolean =
        settings.aiProvider == "anthropic" || effectiveBase().trimEnd('/') == defaultBase("openai")

    /** Texto que explica qué falta, o null si todo está listo. */
    fun problem(): String? {
        if (settings.aiProvider != "openai" && settings.aiProvider != "anthropic") {
            return "No hay ningún proveedor de IA seleccionado."
        }
        val base = effectiveBase()
        if (!base.startsWith("https://")) return "La dirección del servicio debe empezar por https://"
        if (settings.aiModel.isBlank()) return "Falta indicar el nombre del modelo."
        if (needsKey() && !secure.hasKey) return "Falta la clave API."
        return null
    }

    fun isConfigured(): Boolean = problem() == null

    fun providerLabel(): String = when (settings.aiProvider) {
        "openai" -> "Compatible con OpenAI"
        "anthropic" -> "Anthropic"
        else -> "Ninguno"
    }

    fun build(): AiProvider? = when (settings.aiProvider) {
        "openai" -> OpenAiCompatibleProvider(effectiveBase(), settings.aiModel.trim(), secure.apiKey())
        "anthropic" -> AnthropicProvider(effectiveBase(), settings.aiModel.trim(), secure.apiKey())
        else -> null
    }

    /** Fusiona mensajes consecutivos del mismo rol y garantiza que empiece por "user". */
    fun normalize(msgs: List<AiMessage>): List<AiMessage> {
        val out = ArrayList<AiMessage>()
        for (m in msgs) {
            if (out.isNotEmpty() && out.last().role == m.role) {
                out[out.size - 1] = AiMessage(m.role, out.last().content + "\n" + m.content)
            } else {
                out.add(m)
            }
        }
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }

    fun systemPrompt(facts: List<String>, previous: String?): String = buildString {
        val now = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "PE")).format(Date())
        appendLine("Eres ${settings.assistantName}, un asistente personal de voz para Android: educado, sereno, sofisticado y eficiente, como un mayordomo digital.")
        appendLine("Responde en español neutro latinoamericano, salvo que el usuario pida otro idioma o una traducción.")
        appendLine("Tus respuestas se leen en voz alta: sé claro y conciso (normalmente de 1 a 4 frases), sin emojis. Si el usuario pide explicaciones paso a paso, más detalle, resúmenes o ayuda de programación, extiéndete lo necesario; el código va en bloques de código breves y correctos.")
        appendLine("Si no sabes algo o no estás seguro, dilo con honestidad. No inventes datos, cifras ni fuentes.")
        appendLine("No tienes acceso a Internet en tiempo real ni a los datos del teléfono. Las acciones del teléfono (abrir apps, llamadas, mensajes, alarmas) las gestiona la propia aplicación con comandos locales y confirmación del usuario; nunca afirmes haberlas ejecutado tú.")
        appendLine("Si el usuario continúa un tema, usa el contexto de la conversación; si cambia de tema, responde al tema nuevo sin arrastrar el anterior.")
        appendLine("Fecha y hora actuales del dispositivo: $now.")
        if (settings.userName.isNotBlank() && settings.memoryEnabled) appendLine("El usuario se llama ${settings.userName}.")
        if (facts.isNotEmpty()) {
            appendLine("Datos que el usuario pidió recordar:")
            facts.forEach { appendLine("- $it") }
        }
        if (!previous.isNullOrBlank()) {
            appendLine("Fragmento de la conversación anterior (solo contexto; no lo menciones salvo que sea relevante):")
            appendLine(previous)
        }
    }
}
