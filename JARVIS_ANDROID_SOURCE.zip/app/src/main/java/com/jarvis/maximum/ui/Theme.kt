package com.jarvis.maximum.ui

import androidx.compose.ui.graphics.Color

object Holo {
    val Bg0 = Color(0xFF020812)
    val Bg1 = Color(0xFF061B2B)
    val Bg2 = Color(0xFF02050B)
    val Cyan = Color(0xFF36D9FF)
    val Cyan2 = Color(0xFF75E8FF)
    val Blue = Color(0xFF1E90FF)
    val Text = Color(0xFFD4F7FF)
    val Dim = Color(0xFF4CA9C5)
    val Ok = Color(0xFF3DDC97)
    val Warn = Color(0xFFFFB84D)
    val Err = Color(0xFFFF5C6C)
}
