package com.jarvis.maximum.core

import android.Manifest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.jarvis.maximum.ai.AiManager
import com.jarvis.maximum.ai.AiMessage
import com.jarvis.maximum.ai.AiProvider
import com.jarvis.maximum.ai.AiResult
import com.jarvis.maximum.data.MemoryStore
import com.jarvis.maximum.data.SecureStore
import com.jarvis.maximum.data.Settings
import com.jarvis.maximum.phone.PhoneControl
import com.jarvis.maximum.service.WakeWordService
import com.jarvis.maximum.voice.SpeechCallback
import com.jarvis.maximum.voice.SpeechManager
import com.jarvis.maximum.voice.TtsManager
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.Executors

enum class Screen { MAIN, SETTINGS }
enum class AiState { NOT_CONFIGURED, OFFLINE, READY, ERROR }

/**
 * Cerebro de la app. Vive en la clase Application para que la actividad y el servicio de la
 * palabra de activación compartan voz, memoria y estado. Todo el estado mutable se toca en el hilo principal.
 */
class JarvisController(val app: Application) {
    val settings = Settings(app)
    val secure = SecureStore(app)
    val memory = MemoryStore(app, settings)
    val phone = PhoneControl(app)
    val tts = TtsManager(app, settings)
    val speech = SpeechManager(app, settings)
    val ai = AiManager(settings, secure)

    private val router = CommandRouter(this)
    private val main = Handler(Looper.getMainLooper())
    private val aiExecutor = Executors.newSingleThreadExecutor()

    // ---- Estado observable por la interfaz ----
    var screen by mutableStateOf(Screen.MAIN)
    var busy by mutableStateOf(false)
        private set
    var online by mutableStateOf(phone.isOnline())
        private set
    var batteryPercent by mutableStateOf(0)
        private set
    var charging by mutableStateOf(false)
        private set
    var clockMillis by mutableStateOf(System.currentTimeMillis())
        private set
    var pending by mutableStateOf<PendingAction?>(null)
        private set
    var listenMessage by mutableStateOf<String?>(null)
        private set
    var lastAiError by mutableStateOf<String?>(null)
        private set
    var aiTestResult by mutableStateOf<String?>(null)
    var wakeActive by mutableStateOf(false)
        private set
    var wakeStatus by mutableStateOf("Desactivada")
        private set
    var uiVisible = false
        private set

    /** (permiso, alCconceder, alDenegar): la actividad lo implementa. */
    var requestPermission: ((String, () -> Unit, () -> Unit) -> Unit)? = null
    var documentPicker: (() -> Unit)? = null

    private var lastInputWasVoice = false
    private var wakeErrors = 0
    private var tick = 0

    val aiState: AiState
        get() = when {
            !ai.isConfigured() -> AiState.NOT_CONFIGURED
            !online -> AiState.OFFLINE
            lastAiError != null -> AiState.ERROR
            else -> AiState.READY
        }

    init {
        refreshBattery()
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    main.post { refreshNetwork() }
                }

                override fun onLost(network: Network) {
                    main.post { refreshNetwork() }
                }

                override fun onCapabilitiesChanged(network: Network, nc: NetworkCapabilities) {
                    main.post { refreshNetwork() }
                }
            })
        } catch (e: Exception) {
            // Sin callback: el estado de red se refresca al abrir la app.
        }
    }

    private fun refreshNetwork() {
        online = phone.isOnline()
        if (online && lastAiError != null) lastAiError = null
    }

    private fun refreshBattery() {
        batteryPercent = phone.batteryPercent()
        charging = phone.isCharging()
    }

    private val ticker = object : Runnable {
        override fun run() {
            clockMillis = System.currentTimeMillis()
            if (tick++ % 20 == 0) refreshBattery()
            if (uiVisible) main.postDelayed(this, 1000)
        }
    }

    /** La actividad avisa cuando está a la vista (onStart/onStop). */
    fun onUiVisible(visible: Boolean) {
        uiVisible = visible
        main.removeCallbacks(ticker)
        if (visible) {
            refreshNetwork()
            ticker.run()
            if (settings.wakeWordEnabled && !wakeActive && hasMic()) enableWake()
        }
    }

    fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // =====================================================================
    // Conversación
    // =====================================================================

    /** Entrada del usuario (texto o voz). */
    fun submit(text: String, fromVoice: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (speech.isActive && !speech.passive) speech.cancel()
        lastInputWasVoice = fromVoice
        listenMessage = null
        memory.beginTurn()
        memory.add("user", t)
        process(t)
    }

    private fun process(t: String) {
        val waiting = pending
        if (waiting != null) {
            val answer = Text.answer(t)
            pending = null // si no es sí/no, la acción pendiente se descarta
            if (answer == Text.Answer.YES) {
                reply(waiting.onConfirm())
                return
            }
            if (answer == Text.Answer.NO) {
                reply("De acuerdo, cancelado.")
                return
            }
        }

        val routed = router.route(t)
        if (routed != null) {
            handleRouted(routed, t)
            return
        }
        if (busy) {
            reply("Un momento, sigo procesando su solicitud anterior.")
            return
        }
        if (!ai.isConfigured()) {
            reply(OfflineResponder.reply(t, this, OfflineResponder.Reason.NO_AI))
            return
        }
        if (!online) {
            reply(OfflineResponder.reply(t, this, OfflineResponder.Reason.OFFLINE))
            return
        }
        askAi(null)
    }

    private fun handleRouted(r: Routed, original: String) {
        val perm = r.needsPermission
        if (perm != null) {
            reply(r.reply)
            val rp = requestPermission
            if (rp == null) {
                notice("Abra la aplicación y conceda el permiso en Ajustes del teléfono.")
            } else {
                rp(
                    perm,
                    { process(original) },
                    { notice("Sin ese permiso no puedo realizar la acción. Puede concederlo en los ajustes del teléfono.") }
                )
            }
            return
        }
        pending = r.pending
        reply(r.reply, speak = r.speak)
    }

    /** Respuesta del asistente: se guarda, se muestra y (según ajustes) se pronuncia. */
    fun reply(text: String, speak: Boolean = true, role: String = "assistant") {
        memory.add(role, text)
        if (speak && settings.speakReplies) {
            tts.speak(text) { afterSpeech() }
        } else {
            afterSpeech()
        }
    }

    /** Aviso solo visual (no se guarda como respuesta de la IA ni se pronuncia). */
    fun notice(text: String) {
        memory.add("system", text)
    }

    private fun afterSpeech() {
        if (speech.isActive && !speech.passive) return
        if (pending != null && lastInputWasVoice) {
            startListening()
            return
        }
        if (wakeActive) scheduleWake(400)
    }

    fun confirmPending(yes: Boolean) {
        val p = pending ?: return
        pending = null
        lastInputWasVoice = false
        if (yes) {
            memory.add("user", "Confirmo.")
            reply(p.onConfirm())
        } else {
            memory.add("user", "Cancelar.")
            reply("De acuerdo, cancelado.")
        }
    }

    fun newConversation() {
        memory.newConversation()
        pending = null
    }

    fun setMemoryEnabled(enabled: Boolean) {
        settings.memoryEnabled = enabled
        memory.onEnabledChanged(enabled)
    }

    // =====================================================================
    // IA
    // =====================================================================

    /** Si [aiOverride] no es null, sustituye el último mensaje del usuario (p. ej. documento a resumir). */
    private fun askAi(aiOverride: String?) {
        val provider = ai.build()
        if (provider == null) {
            reply(OfflineResponder.reply("", this, OfflineResponder.Reason.NO_AI))
            return
        }
        val system = ai.systemPrompt(memory.activeFacts(), memory.previousExcerpt())
        val history = ai.normalize(memory.context().map { AiMessage(it.role, it.text) }).toMutableList()
        if (aiOverride != null && history.isNotEmpty()) history[history.lastIndex] = AiMessage("user", aiOverride)
        runAi(provider, system, history)
    }

    private fun runAi(provider: AiProvider, system: String, history: List<AiMessage>) {
        busy = true
        aiExecutor.execute {
            val result: AiResult = try {
                provider.chat(system, history)
            } catch (e: UnknownHostException) {
                AiResult.Err("No pude conectar con el servidor de IA. Revise su conexión.")
            } catch (e: SocketTimeoutException) {
                AiResult.Err("El servidor de IA tardó demasiado en responder.")
            } catch (e: IOException) {
                AiResult.Err("Error de red al contactar con la IA.")
            } catch (e: Exception) {
                AiResult.Err("Error inesperado al contactar con la IA.")
            }
            main.post {
                busy = false
                when (result) {
                    is AiResult.Ok -> {
                        lastAiError = null
                        reply(result.text)
                    }
                    is AiResult.Err -> {
                        lastAiError = result.message
                        reply("No pude obtener respuesta de la IA. ${result.message}", role = "system")
                    }
                }
            }
        }
    }

    fun testAi() {
        val problem = ai.problem()
        if (problem != null) {
            aiTestResult = "✗ $problem"
            return
        }
        val provider = ai.build() ?: return
        aiTestResult = "Probando conexión…"
        aiExecutor.execute {
            val r: AiResult = try {
                provider.chat("Responde únicamente con la palabra OK.", listOf(AiMessage("user", "Prueba de conexión")))
            } catch (e: Exception) {
                AiResult.Err("No se pudo conectar: ${e.message ?: e.javaClass.simpleName}")
            }
            main.post {
                when (r) {
                    is AiResult.Ok -> {
                        aiTestResult = "✓ Conexión correcta. Respuesta del modelo: ${r.text.take(60)}"
                        lastAiError = null
                    }
                    is AiResult.Err -> {
                        aiTestResult = "✗ ${r.message}"
                        lastAiError = r.message
                    }
                }
            }
        }
    }

    fun aiStatusText(): String = when (aiState) {
        AiState.NOT_CONFIGURED -> "La inteligencia artificial no está configurada. ${ai.problem() ?: ""} Puede hacerlo en Ajustes."
        AiState.OFFLINE -> "La IA está configurada (${ai.providerLabel()}), pero no hay conexión a Internet."
        AiState.ERROR -> "La IA está configurada, pero el último intento falló. ${lastAiError ?: ""}"
        AiState.READY -> "La IA está configurada: ${ai.providerLabel()}, modelo ${settings.aiModel}. Hay conexión a Internet; la verificaré con la próxima consulta o con «Probar conexión» en Ajustes."
    }

    // ---- Resumen de documentos de texto ----
    fun summarizeDocument(uri: Uri) {
        val name = displayName(uri)
        memory.beginTurn()
        memory.add("user", "Resumir documento: $name")
        if (!ai.isConfigured()) {
            reply("Para resumir documentos necesito una IA conectada. ${ai.problem() ?: ""} Configúrela en Ajustes.")
            return
        }
        if (!online) {
            reply("Para resumir documentos necesito conexión a Internet.")
            return
        }
        if (busy) {
            reply("Un momento, sigo procesando su solicitud anterior.")
            return
        }
        val provider = ai.build() ?: return
        val system = ai.systemPrompt(memory.activeFacts(), null)
        busy = true
        aiExecutor.execute {
            val text = try {
                readDocument(uri)
            } catch (e: Exception) {
                null
            }
            if (text.isNullOrBlank()) {
                main.post {
                    busy = false
                    reply("No pude leer texto de ese archivo. Solo admito archivos de texto plano (.txt, .md, .csv, .json, código…); los PDF y Word aún no.")
                }
                return@execute
            }
            val prompt = "Resume el siguiente documento («$name»). Indica las ideas principales y los puntos clave, en español.\n\n$text"
            val result: AiResult = try {
                provider.chat(system, listOf(AiMessage("user", prompt)))
            } catch (e: Exception) {
                AiResult.Err("No pude contactar con la IA.")
            }
            main.post {
                busy = false
                when (result) {
                    is AiResult.Ok -> {
                        lastAiError = null
                        reply(result.text)
                    }
                    is AiResult.Err -> {
                        lastAiError = result.message
                        reply("No pude resumir el documento. ${result.message}", role = "system")
                    }
                }
            }
        }
    }

    private fun displayName(uri: Uri): String = try {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "documento"
    } catch (e: Exception) {
        "documento"
    }

    private fun readDocument(uri: Uri): String? {
        app.contentResolver.openInputStream(uri)?.use { input ->
            val buf = ByteArray(200_000)
            var total = 0
            while (total < buf.size) {
                val r = input.read(buf, total, buf.size - total)
                if (r <= 0) break
                total += r
            }
            if (total == 0) return null
            for (i in 0 until minOf(total, 4000)) if (buf[i] == 0.toByte()) return null // binario
            return String(buf, 0, total, Charsets.UTF_8).take(60_000)
        }
        return null
    }

    // =====================================================================
    // Escucha de órdenes (reconocimiento de voz dentro de la app)
    // =====================================================================

    fun toggleListening() {
        if (speech.isActive && !speech.passive) {
            speech.cancel()
            listenMessage = null
            afterSpeech()
        } else {
            startListening()
        }
    }

    fun startListening(): Boolean {
        if (!hasMic()) {
            val rp = requestPermission
            if (rp == null) {
                listenMessage = "Falta el permiso del micrófono."
            } else {
                rp(
                    Manifest.permission.RECORD_AUDIO,
                    { startListening() },
                    { listenMessage = "Necesito el permiso del micrófono para escucharle." }
                )
            }
            return false
        }
        tts.stop()
        main.removeCallbacks(wakeRunnable)
        listenMessage = null
        speech.listen(false, commandCallback)
        return true
    }

    private val commandCallback = object : SpeechCallback {
        override fun onFinal(text: String) {
            if (text.isBlank()) {
                listenMessage = "No capté nada. Pulse el micrófono o «Repetir» para intentarlo de nuevo."
                afterSpeech()
            } else {
                submit(text, fromVoice = true)
            }
        }

        override fun onError(code: Int, message: String) {
            listenMessage = message
            afterSpeech()
        }
    }

    // =====================================================================
    // Palabra de activación (servicio en primer plano + SpeechRecognizer en bucle)
    // =====================================================================

    private fun scheduleWake(delayMs: Long) {
        main.removeCallbacks(wakeRunnable)
        if (wakeActive) main.postDelayed(wakeRunnable, delayMs)
    }

    private val wakeRunnable = Runnable {
        if (!wakeActive) return@Runnable
        if (speech.isActive || tts.speaking || busy) {
            scheduleWake(800)
            return@Runnable
        }
        if (!hasMic()) {
            failWake("Falta el permiso del micrófono.")
            return@Runnable
        }
        wakeStatus = "Escuchando «${settings.wakeWord}»"
        speech.listen(true, wakeCallback)
    }

    private val wakeCallback = object : SpeechCallback {
        override fun onFinal(text: String) {
            wakeErrors = 0
            val rest = WakeWord.extract(text, settings.wakeWord)
            when {
                rest == null -> scheduleWake(150)
                rest.length >= 3 -> submit(rest, fromVoice = true)
                else -> {
                    wakeStatus = "Activado: esperando su orden"
                    tts.speak("Dígame.") { startListening() }
                }
            }
        }

        override fun onError(code: Int, message: String) {
            when (code) {
                6, 7 -> {
                    wakeErrors = 0
                    scheduleWake(250)
                }
                8 -> scheduleWake(1500)
                9, -1, 12, 13 -> failWake(message)
                else -> {
                    wakeErrors++
                    if (wakeErrors >= 6) failWake("Reconocimiento inestable: $message") else scheduleWake(2000)
                }
            }
        }
    }

    private fun failWake(reason: String) {
        settings.wakeWordEnabled = false
        wakeStatus = reason
        app.stopService(Intent(app, WakeWordService::class.java))
        onWakeServiceStopped()
        wakeStatus = reason
    }

    /** Activa la escucha de la palabra de activación. Requiere permiso de micrófono y app a la vista. */
    fun enableWake() {
        if (!hasMic()) {
            wakeStatus = "Falta el permiso del micrófono."
            settings.wakeWordEnabled = false
            return
        }
        settings.wakeWordEnabled = true
        try {
            ContextCompat.startForegroundService(app, Intent(app, WakeWordService::class.java))
            wakeStatus = "Iniciando…"
        } catch (e: Exception) {
            settings.wakeWordEnabled = false
            wakeStatus = "Android no permitió iniciar la escucha: ${e.message ?: "error desconocido"}"
        }
    }

    /** Interruptor de Ajustes: pide los permisos necesarios y luego inicia o detiene la escucha. */
    fun setWakeEnabled(enabled: Boolean) {
        if (!enabled) {
            disableWake()
            return
        }
        val rp = requestPermission
        if (rp == null) {
            enableWake()
            return
        }
        rp(
            Manifest.permission.RECORD_AUDIO,
            { rp(Manifest.permission.POST_NOTIFICATIONS, { enableWake() }, { enableWake() }) },
            { wakeStatus = "Sin el permiso del micrófono no puedo escuchar la palabra de activación." }
        )
    }

    fun disableWake() {
        settings.wakeWordEnabled = false
        app.stopService(Intent(app, WakeWordService::class.java))
        onWakeServiceStopped()
    }

    fun onWakeServiceStarted() {
        wakeActive = true
        wakeErrors = 0
        wakeStatus = "Escuchando «${settings.wakeWord}»"
        scheduleWake(300)
    }

    fun onWakeServiceStopped() {
        wakeActive = false
        main.removeCallbacks(wakeRunnable)
        if (speech.isActive && speech.passive) speech.cancel()
        if (wakeStatus.startsWith("Escuchando") || wakeStatus.startsWith("Iniciando") || wakeStatus.startsWith("Activado")) {
            wakeStatus = "Desactivada"
        }
    }

    fun onWakeFailed(reason: String) {
        settings.wakeWordEnabled = false
        wakeActive = false
        wakeStatus = reason
    }

    // =====================================================================
    // Acciones del teléfono
    // =====================================================================

    fun openJarvisSettings(): String =
        if (uiVisible) {
            screen = Screen.SETTINGS
            "Abriendo mis ajustes."
        } else {
            "Abra la aplicación para ver mis ajustes."
        }

    /**
     * Lanza una actividad. Con la app a la vista lo hace directamente (prueba las intenciones en orden).
     * En segundo plano Android lo prohíbe, así que deja una notificación para tocar; nunca finge que se abrió.
     */
    fun launch(intents: List<Intent>, ok: String, what: String): String {
        if (uiVisible) {
            for (i in intents) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    app.startActivity(i)
                    return ok
                } catch (e: ActivityNotFoundException) {
                    continue
                } catch (e: SecurityException) {
                    continue
                }
            }
            return "No hay ninguna aplicación en el teléfono que pueda $what."
        }
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) {
            return "Estoy en segundo plano y Android no me permite abrir aplicaciones desde aquí. Abra J.A.R.V.I.S. y repita la orden."
        }
        val last = intents.last().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val channel = NotificationChannel(ACTION_CHANNEL, "Acciones de J.A.R.V.I.S.", NotificationManager.IMPORTANCE_HIGH)
        app.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val pi = PendingIntent.getActivity(
            app,
            (System.currentTimeMillis() and 0xfffffff).toInt(),
            last,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(app, ACTION_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("J.A.R.V.I.S.")
            .setContentText("Toque para $what")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        return try {
            nm.notify(ACTION_NOTIF_ID, n)
            "Android no permite abrir aplicaciones desde segundo plano. Dejé una notificación: tóquela para $what."
        } catch (e: SecurityException) {
            "Estoy en segundo plano y Android no me permite abrir aplicaciones desde aquí. Abra J.A.R.V.I.S. y repita la orden."
        }
    }

    companion object {
        const val ACTION_CHANNEL = "jarvis_actions"
        const val ACTION_NOTIF_ID = 4201
    }
}
