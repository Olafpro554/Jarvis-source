package com.jarvis.maximum.phone

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat
import com.jarvis.maximum.core.Text
import java.util.Locale

data class AppEntry(val label: String, val pkg: String)
data class ContactMatch(val name: String, val number: String, val normalized: String?, val isMobile: Boolean)
enum class ConnType { NONE, WIFI, MOBILE, OTHER }

/** Acceso a funciones del teléfono que Android permite a una app normal. */
class PhoneControl(private val context: Context) {
    private val pm: PackageManager = context.packageManager

    // ---- Batería ----
    private val battery get() = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    fun batteryPercent(): Int = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    fun isCharging(): Boolean = battery.isCharging

    // ---- Red ----
    private val cm get() = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun caps(): NetworkCapabilities? = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }

    fun isOnline(): Boolean {
        val c = caps() ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun connectionType(): ConnType {
        val c = caps() ?: return ConnType.NONE
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnType.WIFI
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> ConnType.MOBILE
            else -> ConnType.OTHER
        }
    }

    // ---- Información del dispositivo ----
    fun deviceInfo(): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val stat = StatFs(Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024.0 * 1024.0
        fun g(v: Long) = String.format(Locale("es"), "%.1f", v / gb)
        val upHours = SystemClock.elapsedRealtime() / 3_600_000L
        return "Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL}. Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}). " +
            "Memoria RAM: ${g(mi.totalMem)} GB en total, ${g(mi.availMem)} GB libres. " +
            "Almacenamiento: ${g(stat.availableBytes)} GB libres de ${g(stat.totalBytes)} GB. " +
            "Encendido desde hace $upHours horas."
    }

    // ---- Volumen (flujo multimedia) ----
    private val audio get() = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun volumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max == 0) 0 else audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    fun adjustVolume(up: Boolean) {
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun setVolumePercent(percent: Int) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val idx = (percent.coerceIn(0, 100) * max / 100.0).toInt().coerceIn(0, max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, AudioManager.FLAG_SHOW_UI)
    }

    // ---- Aplicaciones ----
    fun launchableApps(): List<AppEntry> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
    }

    fun launchIntent(pkg: String): Intent? = pm.getLaunchIntentForPackage(pkg)

    // ---- Contactos ----
    fun hasContactsPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private val stop = setOf("mi", "mis", "el", "la", "los", "las", "de", "del", "a", "al")

    fun searchContacts(query: String): List<ContactMatch> {
        val tokens = Text.clean(query).split(" ").filter { it.length > 1 && it !in stop }
        if (tokens.isEmpty()) return emptyList()
        val proj = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.NORMALIZED_NUMBER, Phone.TYPE)
        val out = ArrayList<ContactMatch>()
        context.contentResolver.query(Phone.CONTENT_URI, proj, null, null, Phone.DISPLAY_NAME + " ASC")?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val folded = Text.fold(name)
                if (tokens.all { folded.contains(it) }) {
                    out.add(ContactMatch(name, number, c.getString(2), c.getInt(3) == Phone.TYPE_MOBILE))
                }
            }
        }
        return out.sortedWith(compareBy({ Text.fold(it.name).length }, { !it.isMobile }))
    }
}
