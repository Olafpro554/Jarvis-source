package com.jarvis.maximum.core

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Calendar

/** Respuestas básicas predefinidas cuando no hay IA o no hay Internet. No finge conversar. */
object OfflineResponder {
    enum class Reason { NO_AI, OFFLINE }

    private val jokes = listOf(
        "¿Qué le dice un bit a otro? Nos vemos en el bus.",
        "¿Por qué los programadores confunden Halloween con Navidad? Porque 31 de octubre es igual a 25 de diciembre.",
        "Un SQL entra a un bar, se acerca a dos mesas y pregunta: ¿puedo unirme?"
    )

    fun reply(input: String, c: JarvisController, reason: Reason): String {
        val n = Text.clean(input)
        val name = c.settings.assistantName
        val user = if (c.settings.userName.isNotBlank() && c.settings.memoryEnabled) ", ${c.settings.userName}" else ""

        if (Regex("""^(?:hola|buenas|buenos dias|buenas tardes|buenas noches|hey|que tal|saludos)\b""").containsMatchIn(n)) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val g = when (h) {
                in 5..11 -> "Buenos días"
                in 12..19 -> "Buenas tardes"
                else -> "Buenas noches"
            }
            return "$g$user. ¿En qué puedo servirle?"
        }
        if (Regex("""\bgracias\b""").containsMatchIn(n)) return "Es un placer$user."
        if (Regex("""\bcomo estas\b|\bcomo te va\b""").containsMatchIn(n)) return "Operativo y a su servicio$user."
        if (Regex("""\bquien eres\b|\bcomo te llamas\b|\bcual es tu nombre\b""").containsMatchIn(n)) {
            return "Soy $name, su asistente personal. Ahora mismo funciono en modo local: ${if (reason == Reason.NO_AI) "sin proveedor de IA configurado" else "sin conexión a Internet"}."
        }
        if (Regex("""\bchiste\b""").containsMatchIn(n)) return jokes.random()

        calc(input)?.let { return it }

        val limits = if (reason == Reason.NO_AI) {
            "No hay ningún proveedor de inteligencia artificial configurado, así que no puedo mantener conversaciones ni responder preguntas abiertas. Puede configurarlo en Ajustes, en la sección de inteligencia artificial."
        } else {
            "No hay conexión a Internet, así que la inteligencia artificial no está disponible ahora."
        }
        return "$limits Mientras tanto, en modo local puedo abrir aplicaciones, decir la hora, la fecha y la batería, ajustar el volumen, crear alarmas, preparar llamadas y mensajes, hacer cálculos sencillos y recordar datos. Diga «ayuda» para ver la lista."
    }

    // ---- Calculadora sencilla ----
    private fun calc(input: String): String? {
        var f = Text.fold(input).trim().trimEnd('?', '.', '!', ' ')
        val m = Regex("""^(?:cuanto es|cuanto son|calcula|resuelve|dime cuanto es)\s+(.+)$""").find(f) ?: return null
        f = m.groupValues[1]
        Regex("""^raiz cuadrada de\s+([\d.,]+)$""").find(f)?.let {
            val v = it.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
            if (v < 0) return "No existe la raíz cuadrada real de un número negativo."
            return "La raíz cuadrada de ${fmt(v)} es ${fmt(Math.sqrt(v))}."
        }
        f = f.replace("multiplicado por", "*").replace("dividido entre", "/").replace("dividido por", "/")
            .replace(" mas ", "+").replace(" menos ", "-").replace(" por ", "*").replace(" entre ", "/")
            .replace(" x ", "*").replace(',', '.').replace(" ", "")
        if (!Regex("""^[0-9.+\-*/()]+$""").matches(f)) return null
        return try {
            val r = Parser(f).parse()
            "El resultado es ${fmt(r)}."
        } catch (e: ArithmeticException) {
            "No es posible dividir entre cero."
        } catch (e: Exception) {
            null
        }
    }

    private fun fmt(v: Double): String {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString().replace('.', ',')
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun parse(): Double {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException("sobran caracteres")
            return v
        }

        private fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = factor()
                if (op == '/' && r == 0.0) throw ArithmeticException()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            if (i >= s.length) throw IllegalArgumentException("fin inesperado")
            if (s[i] == '-') {
                i++
                return -factor()
            }
            if (s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("falta )")
                i++
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("número esperado")
            return s.substring(start, i).toDouble()
        }
    }
}
