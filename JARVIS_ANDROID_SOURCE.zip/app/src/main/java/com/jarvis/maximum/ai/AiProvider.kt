package com.jarvis.maximum.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AiMessage(val role: String, val content: String)

sealed class AiResult {
    class Ok(val text: String) : AiResult()
    class Err(val message: String) : AiResult()
}

/** Un proveedor de IA. `chat` es bloqueante: se llama siempre fuera del hilo principal. */
interface AiProvider {
    fun chat(system: String, history: List<AiMessage>): AiResult
}

internal object Http {
    fun postJson(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }

    fun errorText(code: Int, body: String): String {
        val detail = try {
            val o = JSONObject(body)
            o.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            null
        }
        val base = when (code) {
            400 -> "Solicitud rechazada (400). Revise el nombre del modelo."
            401, 403 -> "El proveedor rechazó la clave API ($code)."
            404 -> "No se encontró el modelo o la dirección del servicio (404)."
            429 -> "Límite de uso alcanzado o sin saldo en el proveedor (429)."
            in 500..599 -> "El proveedor tiene un problema temporal ($code)."
            else -> "Error del proveedor ($code)."
        }
        return if (detail != null) "$base Detalle: ${detail.take(200)}" else base
    }
}
