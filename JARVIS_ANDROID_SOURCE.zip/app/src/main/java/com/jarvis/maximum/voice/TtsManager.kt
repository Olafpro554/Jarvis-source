package com.jarvis.maximum.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jarvis.maximum.data.Settings
import java.util.Locale

/** Voz de salida usando los motores TTS instalados en el teléfono. No incluye ni clona ninguna voz. */
class TtsManager(private val context: Context, private val settings: Settings) {

    data class EngineInfo(val packageName: String, val label: String)
    data class VoiceInfo(val name: String, val label: String)

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var queued: Pair<String, (() -> Unit)?>? = null
    private var doneCallback: (() -> Unit)? = null
    private var lastUtteranceId = ""

    var speaking by mutableStateOf(false)
        private set
    var engines by mutableStateOf(listOf<EngineInfo>())
        private set
    var voices by mutableStateOf(listOf<VoiceInfo>())
        private set
    var status by mutableStateOf("Iniciando voz…")
        private set

    init {
        createEngine()
    }

    private fun createEngine() {
        ready = false
        tts?.let { runCatching { it.stop(); it.shutdown() } }
        val engine = settings.ttsEngine.takeIf { it.isNotBlank() }
        tts = if (engine != null) {
            TextToSpeech(context, { st -> onInit(st) }, engine)
        } else {
            TextToSpeech(context) { st -> onInit(st) }
        }
    }

    private fun onInit(statusCode: Int) {
        if (statusCode != TextToSpeech.SUCCESS) {
            if (settings.ttsEngine.isNotBlank()) {
                // El motor elegido ya no existe o falló: volver al predeterminado.
                settings.ttsEngine = ""
                settings.ttsVoice = ""
                createEngine()
            } else {
                status = "No hay ningún motor de voz disponible en el teléfono."
            }
            return
        }
        val t = tts ?: return
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                main.post { speaking = true }
            }

            override fun onDone(utteranceId: String?) {
                main.post { if (utteranceId == lastUtteranceId) finishSpeaking() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { if (utteranceId == lastUtteranceId) finishSpeaking() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                main.post { if (utteranceId == lastUtteranceId) finishSpeaking() }
            }
        })

        engines = runCatching { t.engines.map { EngineInfo(it.name, it.label) } }.getOrDefault(emptyList())

        val candidates = listOf(Locale("es", "US"), Locale("es", "MX"), Locale("es", "419"), Locale("es", "PE"), Locale("es"))
        val loc = candidates.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE } ?: Locale("es")
        t.language = loc

        val all: List<Voice> = runCatching { t.voices?.toList() }.getOrNull().orEmpty()
            .filter { it.locale.language == "es" }
        voices = all.sortedWith(
            compareBy<Voice>({ rank(it.locale) }, { it.isNetworkConnectionRequired }, { -it.quality }, { it.name })
        ).map {
            VoiceInfo(
                it.name,
                it.locale.toLanguageTag() + " · " + it.name +
                    if (it.isNetworkConnectionRequired) " · requiere Internet" else " · local"
            )
        }
        all.firstOrNull { it.name == settings.ttsVoice }?.let { t.voice = it }

        ready = true
        status = if (voices.isEmpty()) "Motor de voz listo (sin lista de voces)." else "Motor de voz listo."
        queued?.let { (text, cb) ->
            queued = null
            doSpeak(text, cb)
        }
    }

    private fun rank(l: Locale): Int = when (l.country) {
        "US" -> 0
        "MX" -> 1
        "419" -> 2
        "PE", "CO", "AR", "CL" -> 3
        else -> 4
    }

    private fun finishSpeaking() {
        speaking = false
        val cb = doneCallback
        doneCallback = null
        cb?.invoke()
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        val clean = speakable(text)
        if (clean.isBlank()) {
            onDone?.invoke()
            return
        }
        if (!ready) {
            queued = clean to onDone
            return
        }
        doSpeak(clean, onDone)
    }

    private fun doSpeak(clean: String, onDone: (() -> Unit)?) {
        val t = tts
        if (t == null) {
            onDone?.invoke()
            return
        }
        t.setSpeechRate(settings.ttsRate)
        t.setPitch(settings.ttsPitch)
        doneCallback = onDone
        val limit = (runCatching { TextToSpeech.getMaxSpeechInputLength() }.getOrDefault(4000) - 200).coerceIn(500, 3000)
        chunk(clean, limit).forEachIndexed { i, part ->
            val id = "jv-${System.nanoTime()}-$i"
            lastUtteranceId = id
            t.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    fun stop() {
        doneCallback = null
        queued = null
        runCatching { tts?.stop() }
        speaking = false
    }

    fun testVoice(assistantName: String) {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greet = when (hour) {
            in 5..11 -> "Buenos días"
            in 12..19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        speak("$greet. Soy $assistantName, a su servicio. Esta es mi voz con los ajustes actuales.")
    }

    fun selectVoice(name: String) {
        settings.ttsVoice = name
        val v = runCatching { tts?.voices?.firstOrNull { it.name == name } }.getOrNull()
        if (v != null) tts?.voice = v
    }

    fun selectEngine(pkg: String) {
        settings.ttsEngine = pkg
        settings.ttsVoice = ""
        voices = emptyList()
        status = "Cambiando de motor de voz…"
        createEngine()
    }

    fun release() {
        runCatching { tts?.stop(); tts?.shutdown() }
    }

    companion object {
        /** Quita markdown, bloques de código y enlaces para que la voz no los deletree. */
        fun speakable(text: String): String {
            var s = text.replace(Regex("```[\\s\\S]*?```"), " He dejado el código en pantalla. ")
            s = s.replace(Regex("\\[(.*?)]\\(.*?\\)"), "$1")
            s = s.replace(Regex("https?://\\S+"), " enlace ")
            s = s.replace(Regex("`([^`]*)`"), "$1")
            s = s.replace(Regex("[*_#>]+"), "")
            return s.replace(Regex("\\s+"), " ").trim()
        }

        fun chunk(text: String, limit: Int): List<String> {
            if (text.length <= limit) return listOf(text)
            val out = ArrayList<String>()
            var rest = text
            while (rest.length > limit) {
                var cut = rest.lastIndexOf(". ", limit)
                if (cut < limit / 3) cut = rest.lastIndexOf(' ', limit)
                if (cut <= 0) cut = limit
                out.add(rest.substring(0, cut + 1).trim())
                rest = rest.substring(cut + 1).trim()
            }
            if (rest.isNotEmpty()) out.add(rest)
            return out
        }
    }
}
