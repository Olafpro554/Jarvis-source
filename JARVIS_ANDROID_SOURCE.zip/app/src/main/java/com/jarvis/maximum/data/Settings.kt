package com.jarvis.maximum.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.reflect.KProperty

/** Preferencia persistente y observable por Compose. */
class Pref<T : Any>(
    private val prefs: SharedPreferences,
    private val key: String,
    default: T
) {
    private val state = mutableStateOf(read(default))

    @Suppress("UNCHECKED_CAST")
    private fun read(d: T): T {
        val v: Any = when (d) {
            is String -> prefs.getString(key, d) ?: d
            is Boolean -> prefs.getBoolean(key, d)
            is Float -> prefs.getFloat(key, d)
            is Int -> prefs.getInt(key, d)
            else -> d
        }
        return v as T
    }

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T = state.value

    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        state.value = value
        val e = prefs.edit()
        when (value) {
            is String -> e.putString(key, value)
            is Boolean -> e.putBoolean(key, value)
            is Float -> e.putFloat(key, value)
            is Int -> e.putInt(key, value)
            else -> {}
        }
        e.apply()
    }
}

class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    // Identidad
    var assistantName by Pref(prefs, "assistantName", "J.A.R.V.I.S.")
    var userName by Pref(prefs, "userName", "")

    // Palabra de activación
    var wakeWord by Pref(prefs, "wakeWord", "jarvis")
    var wakeWordEnabled by Pref(prefs, "wakeWordEnabled", false)

    // IA: "none" | "openai" (compatible con OpenAI) | "anthropic"
    var aiProvider by Pref(prefs, "aiProvider", "none")
    var aiBaseUrl by Pref(prefs, "aiBaseUrl", "")
    var aiModel by Pref(prefs, "aiModel", "")

    // Voz de salida (TTS)
    var ttsEngine by Pref(prefs, "ttsEngine", "")
    var ttsVoice by Pref(prefs, "ttsVoice", "")
    var ttsRate by Pref(prefs, "ttsRate", 0.92f)
    var ttsPitch by Pref(prefs, "ttsPitch", 0.82f)
    var speakReplies by Pref(prefs, "speakReplies", true)

    // Reconocimiento de voz
    var recognitionLanguage by Pref(prefs, "recognitionLanguage", "es-PE")
    var preferOfflineRecognition by Pref(prefs, "preferOffline", false)

    // Memoria y teléfono
    var memoryEnabled by Pref(prefs, "memoryEnabled", true)
    var countryCode by Pref(prefs, "countryCode", "51")
}
