package com.jarvis.maximum.data

import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** role: "user" | "assistant" | "system" (avisos de la app; nunca se envían a la IA). */
data class ChatMessage(val role: String, val text: String, val time: Long, val conv: Long)

/**
 * Memoria local: historial de conversaciones y datos que el usuario pidió recordar.
 * Se guarda en el almacenamiento privado de la app (filesDir). No sale del teléfono salvo
 * el contexto que se envía al proveedor de IA que usted configure.
 */
class MemoryStore(context: Context, private val settings: Settings) {
    val messages = mutableStateListOf<ChatMessage>()
    val facts = mutableStateListOf<String>()
    var currentConv by mutableStateOf(System.currentTimeMillis())
        private set

    private val file = File(context.filesDir, "memory.json")
    private val io = Executors.newSingleThreadExecutor()

    init {
        if (settings.memoryEnabled) load()
        val last = messages.lastOrNull()
        currentConv = if (settings.memoryEnabled && last != null &&
            System.currentTimeMillis() - last.time < STALE_MS
        ) last.conv else System.currentTimeMillis()
    }

    private fun load() {
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            o.optJSONArray("facts")?.let { a -> for (i in 0 until a.length()) facts.add(a.getString(i)) }
            o.optJSONArray("messages")?.let { a ->
                for (i in 0 until a.length()) {
                    val m = a.getJSONObject(i)
                    messages.add(ChatMessage(m.getString("r"), m.getString("t"), m.getLong("ts"), m.getLong("c")))
                }
            }
        } catch (e: Exception) {
            Log.w("MemoryStore", "No se pudo leer la memoria", e)
        }
    }

    private fun persist() {
        if (!settings.memoryEnabled) return
        val o = JSONObject()
        o.put("facts", JSONArray(facts.toList()))
        val arr = JSONArray()
        messages.toList().takeLast(MAX_STORED).forEach {
            arr.put(JSONObject().put("r", it.role).put("t", it.text).put("ts", it.time).put("c", it.conv))
        }
        o.put("messages", arr)
        val data = o.toString()
        io.execute {
            try {
                val tmp = File(file.path + ".tmp")
                tmp.writeText(data)
                tmp.renameTo(file)
            } catch (e: Exception) {
                Log.w("MemoryStore", "No se pudo guardar la memoria", e)
            }
        }
    }

    /** Llamar antes de añadir un mensaje del usuario: si pasó mucho tiempo, es una conversación nueva. */
    fun beginTurn() {
        val last = messages.lastOrNull { it.conv == currentConv }
        if (last != null && System.currentTimeMillis() - last.time > STALE_MS) newConversation()
    }

    fun newConversation() {
        val now = System.currentTimeMillis()
        currentConv = if (now == currentConv) now + 1 else now
    }

    fun add(role: String, text: String) {
        messages.add(ChatMessage(role, text, System.currentTimeMillis(), currentConv))
        persist()
    }

    fun conversation(): List<ChatMessage> = messages.filter { it.conv == currentConv }

    /** Últimos mensajes de la conversación actual para enviar como contexto a la IA. */
    fun context(maxMessages: Int = 16): List<ChatMessage> =
        messages.filter { it.conv == currentConv && it.role != "system" }.takeLast(maxMessages)

    /** Fragmento de la conversación anterior (solo si la memoria está activada). */
    fun previousExcerpt(): String? {
        if (!settings.memoryEnabled) return null
        val prev = messages.filter { it.conv != currentConv && it.role != "system" }
        if (prev.isEmpty()) return null
        val lastConv = prev.last().conv
        return prev.filter { it.conv == lastConv }.takeLast(6).joinToString("\n") {
            (if (it.role == "user") "Usuario: " else "Asistente: ") + it.text.take(300)
        }
    }

    fun activeFacts(): List<String> = if (settings.memoryEnabled) facts.toList() else emptyList()

    fun addFact(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || !settings.memoryEnabled) return false
        if (facts.any { it.equals(t, ignoreCase = true) }) return true
        facts.add(t)
        persist()
        return true
    }

    fun removeFact(index: Int) {
        if (index in facts.indices) {
            facts.removeAt(index)
            persist()
        }
    }

    fun removeFactsContaining(term: String): Int {
        val before = facts.size
        facts.removeAll { it.contains(term, ignoreCase = true) }
        persist()
        return before - facts.size
    }

    fun clearHistory() {
        messages.clear()
        newConversation()
        persist()
    }

    fun clearAll() {
        messages.clear()
        facts.clear()
        settings.userName = ""
        newConversation()
        io.execute { runCatching { file.delete() } }
    }

    /** Se llama al activar/desactivar la memoria desde Ajustes o por voz. */
    fun onEnabledChanged(enabled: Boolean) {
        if (enabled) {
            val session = messages.toList()
            messages.clear()
            facts.clear()
            load()
            session.forEach { m ->
                if (messages.none { it.time == m.time && it.text == m.text }) messages.add(m)
            }
            persist()
        } else {
            newConversation() // lo anterior deja de usarse como contexto
        }
    }

    companion object {
        const val STALE_MS = 30 * 60 * 1000L
        const val MAX_STORED = 400
    }
}
