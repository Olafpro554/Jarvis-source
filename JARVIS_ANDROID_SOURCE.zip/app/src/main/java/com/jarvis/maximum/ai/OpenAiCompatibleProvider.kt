package com.jarvis.maximum.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Cualquier servicio que implemente POST {base}/chat/completions con el formato de OpenAI
 * (OpenAI, y muchos otros compatibles). La dirección, el modelo y la clave los pone el usuario.
 */
class OpenAiCompatibleProvider(
    private val baseUrl: String,
    private val model: String,
    private val apiKey: String
) : AiProvider {

    override fun chat(system: String, history: List<AiMessage>): AiResult {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val headers = if (apiKey.isNotBlank()) mapOf("Authorization" to "Bearer $apiKey") else emptyMap()

        val (code, text) = Http.postJson(baseUrl.trimEnd('/') + "/chat/completions", headers, body)
        if (code !in 200..299) return AiResult.Err(Http.errorText(code, text))
        return try {
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            if (content.isBlank()) AiResult.Err("El proveedor devolvió una respuesta vacía.") else AiResult.Ok(content.trim())
        } catch (e: Exception) {
            AiResult.Err("No pude interpretar la respuesta del proveedor.")
        }
    }
}
